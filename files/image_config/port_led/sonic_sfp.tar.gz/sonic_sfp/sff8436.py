#! /usr/bin/env python
#----------------------------------------------------------------------------
# SFF-8436 QSFP+ 10 Gbs 4X PLUGGABLE TRANSCEIVER
#----------------------------------------------------------------------------
from __future__ import print_function
try :
 import fcntl
 import struct
 import sys
 import time
 import binascii
 import os
 import getopt
 import types
 from math import log10
 from sffbase import sffbase
except ImportError as e :
 raise ImportError ( str ( e ) + "- required module not found" )
class sff8436InterfaceId ( sffbase ) :
 version = '1.0'
 specification_compliance = { '10/40G Ethernet Compliance Code' :
 { 'offset' : 3 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : {
 'Extended' :
 { 'offset' : 3 ,
 'bit' : 7 } ,
 '10GBase-LRM' :
 { 'offset' : 3 ,
 'bit' : 6 } ,
 '10GBase-LR' :
 { 'offset' : 3 ,
 'bit' : 5 } ,
 '10GBase-SR' :
 { 'offset' : 3 ,
 'bit' : 4 } ,
 '40GBASE-CR4' :
 { 'offset' : 3 ,
 'bit' : 3 } ,
 '40GBASE-SR4' :
 { 'offset' : 3 ,
 'bit' : 2 } ,
 '40GBASE-LR4' :
 { 'offset' : 3 ,
 'bit' : 1 } ,
 '40G Active Cable (XLPPI)' :
 { 'offset' : 3 ,
 'bit' : 0 } } } ,
 'SONET Compliance codes' :
 { 'offset' : 4 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : {
 '40G OTN (OTU3B/OTU3C)' :
 { 'offset' : 4 ,
 'bit' : 3 } ,
 'OC 48, long reach' :
 { 'offset' : 4 ,
 'bit' : 2 } ,
 'OC 48, intermediate reach' :
 { 'offset' : 4 ,
 'bit' : 1 } ,
 'OC 48 short reach' :
 { 'offset' : 4 ,
 'bit' : 0 } } } ,
 'SAS/SATA compliance codes' :
 { 'offset' : 5 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : {
 'SAS 6.0G' :
 { 'offset' : 5 ,
 'bit' : 5 } ,
 'SAS 3.0G' :
 { 'offset' : 5 ,
 'bit' : 4 } } } ,
 'Gigabit Ethernet Compliant codes' :
 { 'offset' : 6 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : {
 '1000BASE-T' :
 { 'offset' : 6 ,
 'bit' : 3 } ,
 '1000BASE-CX' :
 { 'offset' : 6 ,
 'bit' : 2 } ,
 '1000BASE-LX' :
 { 'offset' : 6 ,
 'bit' : 1 } ,
 '1000BASE-SX' :
 { 'offset' : 6 ,
 'bit' : 0 } } } ,
 'Fibre Channel link length/Transmitter Technology' :
 { 'offset' : 7 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' : {
 'Very long distance (V)' :
 { 'offset' : 7 ,
 'bit' : 7 } ,
 'Short distance (S)' :
 { 'offset' : 7 ,
 'bit' : 6 } ,
 'Intermediate distance (I)' :
 { 'offset' : 7 ,
 'bit' : 5 } ,
 'Long distance (L)' :
 { 'offset' : 7 ,
 'bit' : 4 } ,
 'Medium (M)' :
 { 'offset' : 7 ,
 'bit' : 3 } ,
 'Longwave laser (LC)' :
 { 'offset' : 7 ,
 'bit' : 1 } ,
 'Electrical inter-enclosure (EL)' :
 { 'offset' : 7 ,
 'bit' : 0 } ,
 'Electrical intra-enclosure' :
 { 'offset' : 8 ,
 'bit' : 7 } ,
 'Shortwave laser w/o OFC (SN)' :
 { 'offset' : 8 ,
 'bit' : 6 } ,
 'Shortwave laser w OFC (SL)' :
 { 'offset' : 8 ,
 'bit' : 5 } ,
 'Longwave Laser (LL)' :
 { 'offset' : 8 ,
 'bit' : 4 } } } ,
 'Fibre Channel transmission media' :
 { 'offset' : 8 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : {
 'Twin Axial Pair (TW)' :
 { 'offset' : 8 ,
 'bit' : 7 } ,
 'Shielded Twisted Pair (TP)' :
 { 'offset' : 8 ,
 'bit' : 6 } ,
 'Miniature Coax (MI)' :
 { 'offset' : 8 ,
 'bit' : 5 } ,
 'Video Coax (TV)' :
 { 'offset' : 8 ,
 'bit' : 4 } ,
 'Multi-mode 62.5m (M6)' :
 { 'offset' : 8 ,
 'bit' : 3 } ,
 'Multi-mode 50m (M5)' :
 { 'offset' : 8 ,
 'bit' : 2 } ,
 'Multi-mode 50um (OM3)' :
 { 'offset' : 8 ,
 'bit' : 1 } ,
 'Single Mode (SM)' :
 { 'offset' : 8 ,
 'bit' : 0 } } } ,
 'Fibre Channel Speed' :
 { 'offset' : 9 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : {
 '1200 Mbytes/Sec' :
 { 'offset' : 9 ,
 'bit' : 7 } ,
 '800 Mbytes/Sec' :
 { 'offset' : 9 ,
 'bit' : 6 } ,
 '1600 Mbytes/Sec' :
 { 'offset' : 9 ,
 'bit' : 5 } ,
 '400 Mbytes/Sec' :
 { 'offset' : 9 ,
 'bit' : 4 } ,
 '200 Mbytes/Sec' :
 { 'offset' : 9 ,
 'bit' : 2 } ,
 '100 Mbytes/Sec' :
 { 'offset' : 9 ,
 'bit' : 0 } } } }
 type_of_transceiver = {
 '00' : 'Unknown or unspecified' ,
 '01' : 'GBIC' ,
 '02' : 'Module/connector soldered to motherboard' ,
 '03' : 'SFP' ,
 '04' : '300 pin XBI' ,
 '05' : 'XENPAK' ,
 '06' : 'XFP' ,
 '07' : 'XFF' ,
 '08' : 'XFP-E' ,
 '09' : 'XPAK' ,
 '0a' : 'X2' ,
 '0b' : 'DWDM-SFP' ,
 '0c' : 'QSFP' ,
 '0d' : 'QSFP+' ,
 '11' : 'QSFP28'
 }
 ext_type_of_transceiver = {
 '00' : 'Power Class 1(1.5W max)' ,
 '04' : 'Power Class 1(1.5W max), CDR present in Tx' ,
 '08' : 'Power Class 1(1.5W max), CDR present in Rx' ,
 '0c' : 'Power Class 1(1.5W max), CDR present in Rx Tx' ,
 '10' : 'Power Class 1(1.5W max), CLEI present' ,
 '14' : 'Power Class 1(1.5W max), CLEI present, CDR present in Tx' ,
 '18' : 'Power Class 1(1.5W max), CLEI present, CDR present in Rx' ,
 '1c' : 'Power Class 1(1.5W max), CLEI present, CDR present in Rx Tx' ,

 '40' : 'Power Class 2(2.0W max)' ,
 '44' : 'Power Class 2(2.0W max), CDR present in Rx' ,
 '48' : 'Power Class 2(2.0W max), CDR present in Tx' ,
 '4c' : 'Power Class 2(2.0W max), CDR present in Rx Tx' ,
 '50' : 'Power Class 2(2.0W max), CLEI present' ,
 '54' : 'Power Class 2(2.0W max), CLEI present, CDR present in Rx' ,
 '58' : 'Power Class 2(2.0W max), CLEI present, CDR present in Tx' ,
 '5c' : 'Power Class 2(2.0W max), CLEI present, CDR present in Rx Tx' ,

 '80' : 'Power Class 3(2.5W max)' ,
 '84' : 'Power Class 3(2.5W max), CDR present in Rx' ,
 '88' : 'Power Class 3(2.5W max), CDR present in Tx' ,
 '8c' : 'Power Class 3(2.5W max), CDR present in Rx Tx' ,
 '90' : 'Power Class 3(2.5W max), CLEI present' ,
 '94' : 'Power Class 3(2.5W max), CLEI present, CDR present in Rx' ,
 '98' : 'Power Class 3(2.5W max), CLEI present, CDR present in Tx' ,
 '9c' : 'Power Class 3(2.5W max), CLEI present, CDR present in Rx Tx' ,

 'c0' : 'Power Class 4(3.5W max)' ,
 'c4' : 'Power Class 4(3.5W max), CDR present in Rx' ,
 'c8' : 'Power Class 4(3.5W max), CDR present in Tx' ,
 'cc' : 'Power Class 4(3.5W max), CDR present in Rx Tx' ,
 'd0' : 'Power Class 4(3.5W max), CLEI present' ,
 'd4' : 'Power Class 4(3.5W max), CLEI present, CDR present in Rx' ,
 'd8' : 'Power Class 4(3.5W max), CLEI present, CDR present in Tx' ,
 'dc' : 'Power Class 4(3.5W max), CLEI present, CDR present in Rx Tx'
 }
 connector = {
 '00' : 'Unknown or unspecified' ,
 '01' : 'SC' ,
 '02' : 'FC Style 1 copper connector' ,
 '03' : 'FC Style 2 copper connector' ,
 '04' : 'BNC/TNC' ,
 '05' : 'FC coax headers' ,
 '06' : 'Fiberjack' ,
 '07' : 'LC' ,
 '08' : 'MT-RJ' ,
 '09' : 'MU' ,
 '0a' : 'SG' ,
 '0b' : 'Optical Pigtail' ,
 '0c' : 'MPOx12' ,
 '0d' : 'MPOx16' ,
 '20' : 'HSSDC II' ,
 '21' : 'Copper pigtail' ,
 '22' : 'RJ45' ,
 '23' : 'No separable connector'
 }
 encoding_codes = {
 '00' : 'Unspecified' ,
 '01' : '8B/10B' ,
 '02' : '4B/5B' ,
 '03' : 'NRZ' ,
 '04' : 'SONET Scrambled' ,
 '05' : '64B/66B' ,
 '06' : 'Manchester' ,
 '07' : '256B/257B'
 }
 extended_specification_compliance = { '00' : 'Unspecified' ,
 '01' : '100G AOC or 25GAUI C2M AOC' ,
 '02' : '100GBASE-SR4 or 25GBASE-SR' ,
 '03' : '100GBASE-LR4' ,
 '04' : '100GBASE-ER4' ,
 '06' : '100G CWDM4 MSA with FEC' ,
 '07' : '100G PSM4 Parallel SMF' ,
 '0b' : '100GBASE-CR4 or 25GBASE-CR CA-L' ,
 '18' : '100G AOC or 25GAUI C2M AOC' }
 def calc_length ( self , eeprom_data , offset , size ) :
  OOoO = int ( eeprom_data [ offset ] , 16 )
  OOo = int ( eeprom_data [ offset + 1 ] , 16 )
  Ii1IIii11 = ( OOoO << 8 ) | OOo
  return str ( "%d" % Ii1IIii11 )
 interface_id = { 'Identifier' :
 { 'offset' : 0 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : type_of_transceiver } ,
 'Extended Identifier' :
 { 'offset' : 1 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : ext_type_of_transceiver } ,
 'Connector' :
 { 'offset' : 2 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : connector } ,
 'Specification compliance' :
 { 'offset' : 3 ,
 'type' : 'nested' ,
 'decode' : specification_compliance } ,
 'Encoding' :
 { 'offset' : 11 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : encoding_codes } ,
 'Nominal Bit Rate(100Mbs)' :
 { 'offset' : 12 ,
 'size' : 1 ,
 'type' : 'int' } ,

 'Length(km)' :
 { 'offset' : 14 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'Length OM3(2m)' :
 { 'offset' : 15 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'Length OM2(m)' :
 { 'offset' : 16 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'Length OM1(m)' :
 { 'offset' : 17 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'Length Cable Assembly(m)' :
 { 'offset' : 18 ,
 'size' : 1 ,
 'type' : 'int' } ,

 'Vendor Name' :
 { 'offset' : 20 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'Vendor OUI' :
 { 'offset' : 37 ,
 'size' : 3 ,
 'type' : 'hex' } ,
 'Vendor PN' :
 { 'offset' : 40 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'Vendor Rev' :
 { 'offset' : 56 ,
 'size' : 2 ,
 'type' : 'str' } ,
 'ExtendedSpecificationCompliance' :
 { 'offset' : 64 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : extended_specification_compliance } ,
 'Vendor SN' :
 { 'offset' : 68 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'Vendor Date Code(YYYY-MM-DD Lot)' :
 { 'offset' : 84 ,
 'size' : 8 ,
 'type' : 'date' } ,
 'Diagnostic Monitoring Type' :
 { 'offset' : 92 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : { } } ,
 'Enhanced Options' :
 { 'offset' : 93 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : { } } ,
 'AliPN' :
 { 'offset' : 96 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'LengthCable(UnitsOfmm)' :
 { 'offset' : 112 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_length } } ,
 'CableDiameter(UnitsOfmm)' :
 { 'offset' : 114 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'LaneBitRate(UnitsOfGbps)' :
 { 'offset' : 115 ,
 'size' : 1 ,
 'type' : 'int' } }
 sfp_type = {
 'type' :
 { 'offset' : 0 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : type_of_transceiver }
 }
 vendor_name = {
 'Vendor Name' :
 { 'offset' : 0 ,
 'size' : 16 ,
 'type' : 'str' }
 }
 vendor_pn = {
 'Vendor PN' :
 { 'offset' : 0 ,
 'size' : 16 ,
 'type' : 'str' }
 }
 vendor_rev = {
 'Vendor Rev' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'str' }
 }
 vendor_sn = {
 'Vendor SN' :
 { 'offset' : 0 ,
 'size' : 16 ,
 'type' : 'str' }
 }
 qsfp_dom_capability = {
 'Tx_power_support' :
 { 'offset' : 0 ,
 'bit' : 2 ,
 'type' : 'bitvalue' } ,
 'Rx_power_support' :
 { 'offset' : 0 ,
 'bit' : 3 ,
 'type' : 'bitvalue' } ,
 'Voltage_support' :
 { 'offset' : 0 ,
 'bit' : 4 ,
 'type' : 'bitvalue' } ,
 'Temp_support' :
 { 'offset' : 0 ,
 'bit' : 5 ,
 'type' : 'bitvalue' }
 }
 def __init__ ( self , eeprom_raw_data = None ) :
  self . interface_data = None
  self . calibration_type = 0
  II111iiiiII = 128
  if eeprom_raw_data != None :
   self . interface_data = sffbase . parse ( self ,
 self . interface_id ,
 eeprom_raw_data ,
 II111iiiiII )
   self . handle_xcvr_type ( )
 def handle_xcvr_type ( self ) :
  if self . interface_data is not None and 'data' in self . interface_data :
   O0O00Ooo = self . interface_data [ 'data' ]
   type = self . get_xcvr_type_detail ( O0O00Ooo )
   if type != "" :
    OOoooooO = { }
    OOoooooO [ 'outtype' ] = None
    OOoooooO [ 'value' ] = type
    OOoooooO [ 'short_name' ] = None
    O0O00Ooo [ 'TypeOfTransceiver' ] = OOoooooO
    O0O00Ooo . pop ( 'Specification compliance' )
    O0O00Ooo . pop ( 'ExtendedSpecificationCompliance' )
    O0O00Ooo . pop ( 'Identifier' )
    O0O00Ooo . pop ( 'Extended Identifier' )
   sffbase . handle_xcvr_type ( self , type , O0O00Ooo )
 def get_xcvr_type_detail ( self , intf_data ) :
  type = ''
  try :
   id = intf_data [ 'Identifier' ] [ 'value' ]
   iIi = intf_data [ 'Specification compliance' ] [ 'value' ]
   II = iIi . get ( '10/40G Ethernet Compliance Code' )
   if II is not None :
    iIi = II [ 'value' ]
   else :
    iIi = ''
   iI = intf_data [ 'ExtendedSpecificationCompliance' ] [ 'value' ]
   if cmp ( id , 'QSFP28' ) == 0 and cmp ( iIi , 'Extended' ) == 0 :
    if iI . find ( ' AOC' ) != - 1 :
     type = '100G_AOC_QSFP28'
    elif iI . find ( 'SR4' ) != - 1 :
     type = '100G_SR4_QSFP28'
    elif iI . find ( 'LR4' ) != - 1 :
     type = '100G_LR4_QSFP28'
    elif iI . find ( 'ER4' ) != - 1 :
     type = '100G_ER4_QSFP28'
    elif iI . find ( 'CWDM4' ) != - 1 :
     type = '100G_CWDM4_QSFP28'
    elif iI . find ( 'PSM4' ) != - 1 :
     type = '100G_PSM4_QSFP28'
    elif iI . find ( 'CR4' ) != - 1 :
     type = '100G_DAC_QSFP28'
  except Exception , oo :
   print ( 'Decode ID and ExtendedSepcificationComplianceCodes failed.' )
  return type
 def parse ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . interface_id , eeprom_raw_data , start_pos )
 def parse_sfp_type ( self , type_raw_data , start_pos ) :
  return sffbase . parse ( self , self . sfp_type , type_raw_data , start_pos )
 def parse_vendor_name ( self , name_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_name , name_raw_data , start_pos )
 def parse_vendor_rev ( self , rev_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_rev , rev_raw_data , start_pos )
 def parse_vendor_pn ( self , pn_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_pn , pn_raw_data , start_pos )
 def parse_vendor_sn ( self , sn_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_sn , sn_raw_data , start_pos )
 def parse_qsfp_dom_capability ( self , sn_raw_data , start_pos ) :
  return sffbase . parse ( self , self . qsfp_dom_capability , sn_raw_data , start_pos )
 def dump_pretty ( self ) :
  if self . interface_data == None :
   return
  sffbase . dump_pretty ( self , self . interface_data )
 def get_calibration_type ( self ) :
  return self . calibration_type
 def get_data ( self ) :
  return self . interface_data
 def get_data_pretty ( self ) :
  if self . interface_data == None :
   return
  return sffbase . get_data_pretty ( self , self . interface_data )
class sff8436Dom ( sffbase ) :
 version = '1.0'
 def get_calibration_type ( self ) :
  return self . _calibration_type
 def calc_temperature ( self , eeprom_data , offset , size ) :
  try :
   I1i1I1II = self . get_calibration_type ( )
   OOoO = int ( eeprom_data [ offset ] , 16 )
   OOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Ii1IIii11 = ( OOoO << 8 ) | ( OOo & 0xff )
   Ii1IIii11 = self . twos_comp ( Ii1IIii11 , 16 )
   if I1i1I1II == 1 :
    Ii1IIii11 = float ( Ii1IIii11 / 256.0 )
    I1II1III11iii = '%.4f' % Ii1IIii11 + 'C'
   elif I1i1I1II == 2 :
    ii11i1 = self . dom_ext_calibration_constants [ 'T_Slope' ] [ 'offset' ]
    IIIii1II1II = int ( eeprom_data [ ii11i1 ] , 16 )
    i1I1iI = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    oo0OooOOo0 = ( IIIii1II1II << 8 ) | ( i1I1iI & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'T_Offset' ] [ 'offset' ]
    IIIii1II1II = int ( eeprom_data [ ii11i1 ] , 16 )
    i1I1iI = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    IiII1I11i1I1I = ( IIIii1II1II << 8 ) | ( i1I1iI & 0xff )
    IiII1I11i1I1I = self . twos_comp ( IiII1I11i1I1I , 16 )
    Ii1IIii11 = oo0OooOOo0 * Ii1IIii11 + IiII1I11i1I1I
    Ii1IIii11 = float ( Ii1IIii11 / 256.0 )
    I1II1III11iii = '%.4f' % Ii1IIii11 + 'C'
   else :
    I1II1III11iii = 'Unknown'
  except Exception as iIIIIii1 :
   I1II1III11iii = str ( iIIIIii1 )
  return I1II1III11iii
 def calc_voltage ( self , eeprom_data , offset , size ) :
  try :
   I1i1I1II = self . get_calibration_type ( )
   OOoO = int ( eeprom_data [ offset ] , 16 )
   OOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Ii1IIii11 = ( OOoO << 8 ) | ( OOo & 0xff )
   if I1i1I1II == 1 :
    Ii1IIii11 = float ( Ii1IIii11 * 0.0001 )
    I1II1III11iii = '%.4f' % Ii1IIii11 + 'Volts'
   elif I1i1I1II == 2 :
    ii11i1 = self . dom_ext_calibration_constants [ 'V_Slope' ] [ 'offset' ]
    oOOOO00O0O0 = int ( eeprom_data [ ii11i1 ] , 16 )
    oO0oo0o = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    II11i1I11Ii1i = ( oOOOO00O0O0 << 8 ) | ( oO0oo0o & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'V_Offset' ] [ 'offset' ]
    oOOOO00O0O0 = int ( eeprom_data [ ii11i1 ] , 16 )
    oO0oo0o = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    Oooo0O0oo00oO = ( oOOOO00O0O0 << 8 ) | ( oO0oo0o & 0xff )
    Oooo0O0oo00oO = self . twos_comp ( Oooo0O0oo00oO , 16 )
    Ii1IIii11 = II11i1I11Ii1i * Ii1IIii11 + Oooo0O0oo00oO
    Ii1IIii11 = float ( Ii1IIii11 * 0.0001 )
    I1II1III11iii = '%.4f' % Ii1IIii11 + 'Volts'
   else :
    I1II1III11iii = 'Unknown'
  except Exception as iIIIIii1 :
   I1II1III11iii = str ( iIIIIii1 )
  return I1II1III11iii
 def calc_bias ( self , eeprom_data , offset , size ) :
  try :
   I1i1I1II = self . get_calibration_type ( )
   OOoO = int ( eeprom_data [ offset ] , 16 )
   OOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Ii1IIii11 = ( OOoO << 8 ) | ( OOo & 0xff )
   if I1i1I1II == 1 :
    Ii1IIii11 = float ( Ii1IIii11 * 0.002 )
    I1II1III11iii = '%.4f' % Ii1IIii11 + 'mA'
   elif I1i1I1II == 2 :
    ii11i1 = self . dom_ext_calibration_constants [ 'I_Slope' ] [ 'offset' ]
    o0o = int ( eeprom_data [ ii11i1 ] , 16 )
    o00 = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    OooOO000 = ( o0o << 8 ) | ( o00 & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'I_Offset' ] [ 'offset' ]
    o0o = int ( eeprom_data [ ii11i1 ] , 16 )
    o00 = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    I1111IIi = ( o0o << 8 ) | ( o00 & 0xff )
    I1111IIi = self . twos_comp ( I1111IIi , 16 )
    Ii1IIii11 = OooOO000 * Ii1IIii11 + I1111IIi
    Ii1IIii11 = float ( Ii1IIii11 * 0.002 )
    I1II1III11iii = '%.4f' % Ii1IIii11 + 'mA'
   else :
    I1II1III11iii = 'Unknown'
  except Exception as iIIIIii1 :
   I1II1III11iii = str ( iIIIIii1 )
  return I1II1III11iii
 def calc_tx_power ( self , eeprom_data , offset , size ) :
  try :
   I1i1I1II = self . get_calibration_type ( )
   OOoO = int ( eeprom_data [ offset ] , 16 )
   OOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Ii1IIii11 = ( OOoO << 8 ) | ( OOo & 0xff )
   if I1i1I1II == 1 :
    Ii1IIii11 = float ( Ii1IIii11 * 0.0001 )
    I1II1III11iii = self . power_in_dbm_str ( Ii1IIii11 )
   elif I1i1I1II == 2 :
    ii11i1 = self . dom_ext_calibration_constants [ 'TX_PWR_Slope' ] [ 'offset' ]
    III1IiiI = int ( eeprom_data [ ii11i1 ] , 16 )
    iIi1 = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    IIIII11I1IiI = ( III1IiiI << 8 ) | ( iIi1 & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'TX_PWR_Offset' ] [ 'offset' ]
    III1IiiI = int ( eeprom_data [ ii11i1 ] , 16 )
    iIi1 = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    oOooOOOoOo = ( III1IiiI << 8 ) | ( iIi1 & 0xff )
    oOooOOOoOo = self . twos_comp ( oOooOOOoOo , 16 )
    Ii1IIii11 = IIIII11I1IiI * Ii1IIii11 + oOooOOOoOo
    Ii1IIii11 = float ( Ii1IIii11 * 0.0001 )
    I1II1III11iii = self . power_in_dbm_str ( Ii1IIii11 )
   else :
    I1II1III11iii = 'Unknown'
  except Exception as iIIIIii1 :
   I1II1III11iii = str ( iIIIIii1 )
  return I1II1III11iii
 def calc_rx_power ( self , eeprom_data , offset , size ) :
  try :
   I1i1I1II = self . get_calibration_type ( )
   OOoO = int ( eeprom_data [ offset ] , 16 )
   OOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Ii1IIii11 = ( OOoO << 8 ) | ( OOo & 0xff )
   if I1i1I1II == 1 :
    Ii1IIii11 = float ( Ii1IIii11 * 0.0001 )
    I1II1III11iii = self . power_in_dbm_str ( Ii1IIii11 )
   elif I1i1I1II == 2 :
    ii11i1 = self . dom_ext_calibration_constants [ 'RX_PWR_4' ] [ 'offset' ]
    o0O = int ( eeprom_data [ ii11i1 ] , 16 )
    IiIIii1iII1II = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    Iii1I1I11iiI1 = int ( eeprom_data [ ii11i1 + 2 ] , 16 )
    I1I1i1I = int ( eeprom_data [ ii11i1 + 3 ] , 16 )
    ii1I = ( o0O << 24 ) | ( IiIIii1iII1II << 16 ) | ( Iii1I1I11iiI1 << 8 ) | ( I1I1i1I & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'RX_PWR_3' ] [ 'offset' ]
    o0O = int ( eeprom_data [ ii11i1 ] , 16 )
    IiIIii1iII1II = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    Iii1I1I11iiI1 = int ( eeprom_data [ ii11i1 + 2 ] , 16 )
    I1I1i1I = int ( eeprom_data [ ii11i1 + 3 ] , 16 )
    i11I1II1I11i = ( o0O << 24 ) | ( IiIIii1iII1II << 16 ) | ( Iii1I1I11iiI1 << 8 ) | ( I1I1i1I & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'RX_PWR_2' ] [ 'offset' ]
    o0O = int ( eeprom_data [ ii11i1 ] , 16 )
    IiIIii1iII1II = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    Iii1I1I11iiI1 = int ( eeprom_data [ ii11i1 + 2 ] , 16 )
    I1I1i1I = int ( eeprom_data [ ii11i1 + 3 ] , 16 )
    I1i11i = ( o0O << 24 ) | ( IiIIii1iII1II << 16 ) | ( Iii1I1I11iiI1 << 8 ) | ( I1I1i1I & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'RX_PWR_1' ] [ 'offset' ]
    o0O = int ( eeprom_data [ ii11i1 ] , 16 )
    IiIIii1iII1II = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    Iii1I1I11iiI1 = int ( eeprom_data [ ii11i1 + 2 ] , 16 )
    I1I1i1I = int ( eeprom_data [ ii11i1 + 3 ] , 16 )
    o0 = ( o0O << 24 ) | ( IiIIii1iII1II << 16 ) | ( Iii1I1I11iiI1 << 8 ) | ( I1I1i1I & 0xff )
    ii11i1 = self . dom_ext_calibration_constants [ 'RX_PWR_0' ] [ 'offset' ]
    o0O = int ( eeprom_data [ ii11i1 ] , 16 )
    IiIIii1iII1II = int ( eeprom_data [ ii11i1 + 1 ] , 16 )
    Iii1I1I11iiI1 = int ( eeprom_data [ ii11i1 + 2 ] , 16 )
    I1I1i1I = int ( eeprom_data [ ii11i1 + 3 ] , 16 )
    OOOoo0OO = ( o0O << 24 ) | ( IiIIii1iII1II << 16 ) | ( Iii1I1I11iiI1 << 8 ) | ( I1I1i1I & 0xff )
    Ii1I1Ii = ( ii1I * Ii1IIii11 ) + ( i11I1II1I11i * Ii1IIii11 ) + ( I1i11i * Ii1IIii11 ) + ( o0 * Ii1IIii11 ) + OOOoo0OO
    Ii1IIii11 = float ( Ii1IIii11 * 0.0001 )
    I1II1III11iii = self . power_in_dbm_str ( Ii1IIii11 )
   else :
    I1II1III11iii = 'Unknown'
  except Exception as iIIIIii1 :
   I1II1III11iii = str ( iIIIIii1 )
  return I1II1III11iii
 dom_status_indicator = { 'DataNotReady' :
 { 'offset' : 2 ,
 'bit' : 0 ,
 'type' : 'bitvalue' } }
 dom_channel_status = { 'Tx4LOS' :
 { 'offset' : 3 ,
 'bit' : 7 ,
 'type' : 'bitvalue' } ,
 'Tx3LOS' :
 { 'offset' : 3 ,
 'bit' : 6 ,
 'type' : 'bitvalue' } ,
 'Tx2LOS' :
 { 'offset' : 3 ,
 'bit' : 5 ,
 'type' : 'bitvalue' } ,
 'Tx1LOS' :
 { 'offset' : 3 ,
 'bit' : 4 ,
 'type' : 'bitvalue' } ,
 'Rx4LOS' :
 { 'offset' : 3 ,
 'bit' : 3 ,
 'type' : 'bitvalue' } ,
 'Rx3LOS' :
 { 'offset' : 3 ,
 'bit' : 2 ,
 'type' : 'bitvalue' } ,
 'Rx2LOS' :
 { 'offset' : 3 ,
 'bit' : 1 ,
 'type' : 'bitvalue' } ,
 'Rx1LOS' :
 { 'offset' : 3 ,
 'bit' : 0 ,
 'type' : 'bitvalue' } ,
 'Tx4Fault' :
 { 'offset' : 4 ,
 'bit' : 3 ,
 'type' : 'bitvalue' } ,
 'Tx3Fault' :
 { 'offset' : 4 ,
 'bit' : 2 ,
 'type' : 'bitvalue' } ,
 'Tx2Fault' :
 { 'offset' : 4 ,
 'bit' : 1 ,
 'type' : 'bitvalue' } ,
 'Tx1Fault' :
 { 'offset' : 4 ,
 'bit' : 0 ,
 'type' : 'bitvalue' } ,
 'Tx4LOL' :
 { 'offset' : 5 ,
 'bit' : 7 ,
 'type' : 'bitvalue' } ,
 'Tx3LOL' :
 { 'offset' : 5 ,
 'bit' : 6 ,
 'type' : 'bitvalue' } ,
 'Tx2LOL' :
 { 'offset' : 5 ,
 'bit' : 5 ,
 'type' : 'bitvalue' } ,
 'Tx1LOL' :
 { 'offset' : 5 ,
 'bit' : 4 ,
 'type' : 'bitvalue' } ,
 'Rx4LOL' :
 { 'offset' : 5 ,
 'bit' : 3 ,
 'type' : 'bitvalue' } ,
 'Rx3LOL' :
 { 'offset' : 5 ,
 'bit' : 2 ,
 'type' : 'bitvalue' } ,
 'Rx2LOL' :
 { 'offset' : 5 ,
 'bit' : 1 ,
 'type' : 'bitvalue' } ,
 'Rx1LOL' :
 { 'offset' : 5 ,
 'bit' : 0 ,
 'type' : 'bitvalue' } }
 dom_module_monitor_alarm = {
 'TempHighAlarm' : {
 'offset' : 6 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'TempLowAlarm' : {
 'offset' : 6 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 } ,
 'VccHighAlarm' : {
 'offset' : 7 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'VccLowAlarm' : {
 'offset' : 7 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 }
 }
 dom_module_monitor_warning = {
 'TempHighWarning' : {
 'offset' : 6 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'TempLowWarning' : {
 'offset' : 6 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 } ,
 'VccHighWarning' : {
 'offset' : 7 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'VccLowWarning' : {
 'offset' : 7 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 }
 }
 dom_channel_monitor_alarm = {
 'Rx1PowerHighAlarm' : {
 'offset' : 9 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'Rx1PowerLowAlarm' : {
 'offset' : 9 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 } ,
 'Rx2PowerHighAlarm' : {
 'offset' : 9 ,
 'bit' : 3 ,
 'type' : 'bitvalue'
 } ,
 'Rx2PowerLowAlarm' : {
 'offset' : 9 ,
 'bit' : 2 ,
 'type' : 'bitvalue'
 } ,
 'Rx3PowerHighAlarm' : {
 'offset' : 10 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'Rx3PowerLowAlarm' : {
 'offset' : 10 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 } ,
 'Rx4PowerHighAlarm' : {
 'offset' : 10 ,
 'bit' : 3 ,
 'type' : 'bitvalue'
 } ,
 'Rx4PowerLowAlarm' : {
 'offset' : 10 ,
 'bit' : 2 ,
 'type' : 'bitvalue'
 } ,
 'Tx1BiasHighAlarm' : {
 'offset' : 11 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'Tx1BiasLowAlarm' : {
 'offset' : 11 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 } ,
 'Tx2BiasHighAlarm' : {
 'offset' : 11 ,
 'bit' : 3 ,
 'type' : 'bitvalue'
 } ,
 'Tx2BiasLowAlarm' : {
 'offset' : 11 ,
 'bit' : 2 ,
 'type' : 'bitvalue'
 } ,
 'Tx3BiasHighAlarm' : {
 'offset' : 12 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'Tx3BiasLowAlarm' : {
 'offset' : 12 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 } ,
 'Tx4BiasHighAlarm' : {
 'offset' : 12 ,
 'bit' : 3 ,
 'type' : 'bitvalue'
 } ,
 'Tx4BiasLowAlarm' : {
 'offset' : 12 ,
 'bit' : 2 ,
 'type' : 'bitvalue'
 } ,
 'TX1PowerHighAlarm' : {
 'offset' : 13 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'TX1PowerLowAlarm' : {
 'offset' : 13 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 } ,
 'TX2PowerHighAlarm' : {
 'offset' : 13 ,
 'bit' : 3 ,
 'type' : 'bitvalue'
 } ,
 'TX2PowerLowAlarm' : {
 'offset' : 13 ,
 'bit' : 2 ,
 'type' : 'bitvalue'
 } ,
 'TX3PowerHighAlarm' : {
 'offset' : 14 ,
 'bit' : 7 ,
 'type' : 'bitvalue'
 } ,
 'TX3PowerLowAlarm' : {
 'offset' : 14 ,
 'bit' : 6 ,
 'type' : 'bitvalue'
 } ,
 'TX4PowerHighAlarm' : {
 'offset' : 14 ,
 'bit' : 3 ,
 'type' : 'bitvalue'
 } ,
 'TX4PowerLowAlarm' : {
 'offset' : 14 ,
 'bit' : 2 ,
 'type' : 'bitvalue'
 }
 }
 dom_channel_monitor_warning = {
 'Rx1PowerHighWarning' : {
 'offset' : 9 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'Rx1PowerLowWarning' : {
 'offset' : 9 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 } ,
 'Rx2PowerHighWarning' : {
 'offset' : 9 ,
 'bit' : 1 ,
 'type' : 'bitvalue'
 } ,
 'Rx2PowerLowWarning' : {
 'offset' : 9 ,
 'bit' : 0 ,
 'type' : 'bitvalue'
 } ,
 'Rx3PowerHighWarning' : {
 'offset' : 10 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'Rx3PowerLowWarning' : {
 'offset' : 10 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 } ,
 'Rx4PowerHighWarning' : {
 'offset' : 10 ,
 'bit' : 1 ,
 'type' : 'bitvalue'
 } ,
 'Rx4PowerLowWarning' : {
 'offset' : 10 ,
 'bit' : 0 ,
 'type' : 'bitvalue'
 } ,
 'Tx1BiasHighWarning' : {
 'offset' : 11 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'Tx1BiasLowWarning' : {
 'offset' : 11 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 } ,
 'Tx2BiasHighWarning' : {
 'offset' : 11 ,
 'bit' : 1 ,
 'type' : 'bitvalue'
 } ,
 'Tx2BiasLowWarning' : {
 'offset' : 11 ,
 'bit' : 0 ,
 'type' : 'bitvalue'
 } ,
 'Tx3BiasHighWarning' : {
 'offset' : 12 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'Tx3BiasLowWarning' : {
 'offset' : 12 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 } ,
 'Tx4BiasHighWarning' : {
 'offset' : 12 ,
 'bit' : 1 ,
 'type' : 'bitvalue'
 } ,
 'Tx4BiasLowWarning' : {
 'offset' : 12 ,
 'bit' : 0 ,
 'type' : 'bitvalue'
 } ,
 'TX1PowerHighWarning' : {
 'offset' : 13 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'TX1PowerLowWarning' : {
 'offset' : 13 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 } ,
 'TX2PowerHighWarning' : {
 'offset' : 13 ,
 'bit' : 1 ,
 'type' : 'bitvalue'
 } ,
 'TX2PowerLowWarning' : {
 'offset' : 13 ,
 'bit' : 0 ,
 'type' : 'bitvalue'
 } ,
 'TX3PowerHighWarning' : {
 'offset' : 14 ,
 'bit' : 5 ,
 'type' : 'bitvalue'
 } ,
 'TX3PowerLowWarning' : {
 'offset' : 14 ,
 'bit' : 4 ,
 'type' : 'bitvalue'
 } ,
 'TX4PowerHighWarning' : {
 'offset' : 14 ,
 'bit' : 1 ,
 'type' : 'bitvalue'
 } ,
 'TX4PowerLowWarning' : {
 'offset' : 14 ,
 'bit' : 0 ,
 'type' : 'bitvalue'
 }
 }
 dom_module_monitor_values = { 'Temperature' :
 { 'offset' : 22 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } } ,
 'Vcc' :
 { 'offset' : 26 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } } }
 dom_channel_monitor_values = {
 'RX1Power' :
 { 'offset' : 34 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX2Power' :
 { 'offset' : 36 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX3Power' :
 { 'offset' : 38 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX4Power' :
 { 'offset' : 40 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'TX1Bias' :
 { 'offset' : 42 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX2Bias' :
 { 'offset' : 44 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX3Bias' :
 { 'offset' : 46 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX4Bias' :
 { 'offset' : 48 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } }
 dom_map = {
 'ModuleMonitorAlarmFlagsStatus' : {
 'offset' : 6 ,
 'size' : 2 ,
 'type' : 'nested' ,
 'decode' : dom_module_monitor_alarm } ,
 'ModuleMonitorWarningFlagsStatus' : {
 'offset' : 6 ,
 'size' : 2 ,
 'type' : 'nested' ,
 'decode' : dom_module_monitor_warning } ,
 'ModuleMonitorValues' : {
 'offset' : 22 ,
 'size' : 8 ,
 'type' : 'nested' ,
 'decode' : dom_module_monitor_values } ,
 'ChannelMonitorAlarmFlagsStatus' : {
 'offset' : 9 ,
 'size' : 6 ,
 'type' : 'nested' ,
 'decode' : dom_channel_monitor_alarm } ,
 'ChannelMonitorWarningFlagsStatus' : {
 'offset' : 9 ,
 'size' : 6 ,
 'type' : 'nested' ,
 'decode' : dom_channel_monitor_warning } ,
 'ChannelMonitorValues' : {
 'offset' : 34 ,
 'size' : 8 ,
 'type' : 'nested' ,
 'decode' : dom_channel_monitor_values } ,
 'ChannelStatus' : {
 'offset' : 3 ,
 'size' : 3 ,
 'type' : 'nested' ,
 'decode' : dom_channel_status } }
 revision_compliance = {
 '00' : 'Revision not specified' ,
 '01' : 'SFF-8436 Rev 4.8' ,
 '02' : 'SFF-8436 Rev 4.8 with extra bytes support' ,
 '03' : 'SFF-8636 Rev 1.3' ,
 '04' : 'SFF-8636 Rev 1.4' ,
 '05' : 'SFF-8636 Rev 1.5' ,
 '06' : 'SFF-8636 Rev 2.0' ,
 '07' : 'SFF-8636 Rev 2.5'
 }
 sfp_dom_rev = {
 'dom_rev' :
 { 'offset' : 0 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : revision_compliance }
 }
 dom_module_temperature = {
 'Temperature' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } }
 }
 dom_module_voltage = {
 'Vcc' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } }
 }
 dom_channel_monitor_params = {
 'RX1Power' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX2Power' :
 { 'offset' : 2 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX3Power' :
 { 'offset' : 4 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX4Power' :
 { 'offset' : 6 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'TX1Bias' :
 { 'offset' : 8 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX2Bias' :
 { 'offset' : 10 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX3Bias' :
 { 'offset' : 12 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX4Bias' :
 { 'offset' : 14 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } }
 }
 dom_channel_monitor_params_with_tx_power = {
 'RX1Power' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX2Power' :
 { 'offset' : 2 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX3Power' :
 { 'offset' : 4 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RX4Power' :
 { 'offset' : 6 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'TX1Bias' :
 { 'offset' : 8 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX2Bias' :
 { 'offset' : 10 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX3Bias' :
 { 'offset' : 12 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX4Bias' :
 { 'offset' : 14 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TX1Power' :
 { 'offset' : 16 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'TX2Power' :
 { 'offset' : 18 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'TX3Power' :
 { 'offset' : 20 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'TX4Power' :
 { 'offset' : 22 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } }
 }
 def __init__ ( self , eeprom_raw_data = None , calibration_type = 1 ) :
  self . _calibration_type = calibration_type
  II111iiiiII = 0
  if eeprom_raw_data != None :
   self . dom_data = sffbase . parse ( self , self . dom_map ,
 eeprom_raw_data , II111iiiiII )
 def parse ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_map , eeprom_raw_data ,
 start_pos )
 def parse_sfp_dom_rev ( self , type_raw_data , start_pos ) :
  return sffbase . parse ( self , self . sfp_dom_rev , type_raw_data , start_pos )
 def parse_temperature ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_module_temperature , eeprom_raw_data ,
 start_pos )
 def parse_voltage ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_module_voltage , eeprom_raw_data ,
 start_pos )
 def parse_channel_monitor_params ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_channel_monitor_params , eeprom_raw_data ,
 start_pos )
 def parse_channel_monitor_params_with_tx_power ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_channel_monitor_params_with_tx_power , eeprom_raw_data ,
 start_pos )
 def dump_pretty ( self ) :
  if self . dom_data == None :
   return
  sffbase . dump_pretty ( self , self . dom_data )
 def get_data ( self ) :
  return self . dom_data
 def get_data_pretty ( self ) :
  if self . dom_data == None :
   return
  return sffbase . get_data_pretty ( self , self . dom_data )
class sff8636DomPage3 ( sff8436Dom ) :
 version = '1.0'
 dom_aw_thresholds = {
 'TempHighAlarm' : {
 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_temperature
 }
 } ,
 'TempLowAlarm' : {
 'offset' : 2 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_temperature
 }
 } ,
 'TempHighWarning' : {
 'offset' : 4 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_temperature
 }
 } ,
 'TempLowWarning' : {
 'offset' : 6 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_temperature
 }
 } ,
 'VoltageHighAlarm' : {
 'offset' : 16 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_voltage
 }
 } ,
 'VoltageLowAlarm' : {
 'offset' : 18 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_voltage
 }
 } ,
 'VoltageHighWarning' : {
 'offset' : 20 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_voltage
 }
 } ,
 'VoltageLowWarning' : {
 'offset' : 22 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_voltage
 }
 } ,
 'RXPowerHighAlarm' : {
 'offset' : 48 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_rx_power
 }
 } ,
 'RXPowerLowAlarm' : {
 'offset' : 50 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_rx_power
 }
 } ,
 'RXPowerHighWarning' : {
 'offset' : 52 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_rx_power
 }
 } ,
 'RXPowerLowWarning' : {
 'offset' : 54 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_rx_power
 }
 } ,
 'TXBiasHighAlarm' : {
 'offset' : 56 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_bias
 }
 } ,
 'TXBiasLowAlarm' : {
 'offset' : 58 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_bias
 }
 } ,
 'TXBiasHighWarning' : {
 'offset' : 60 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_bias
 }
 } ,
 'TXBiasLowWarning' : {
 'offset' : 62 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_bias
 }
 } ,
 'TXPowerHighAlarm' : {
 'offset' : 64 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_tx_power
 }
 } ,
 'TXPowerLowAlarm' : {
 'offset' : 66 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_tx_power
 }
 } ,
 'TXPowerHighWarning' : {
 'offset' : 68 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_tx_power
 }
 } ,
 'TXPowerLowWarning' : {
 'offset' : 70 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : sff8436Dom . calc_tx_power
 }
 }
 }
 def decode_tx_equalization ( self , eeprom_data , offset , size ) :
  if size == 2 :
   o00Oo0oooooo = ( int ( eeprom_data [ offset ] , 16 ) & 0xf0 ) >> 4
  else :
   o00Oo0oooooo = int ( eeprom_data [ offset ] , 16 ) & 0xf
  if o00Oo0oooooo not in range ( 11 ) :
   Ii1IIii11 = "Reserved"
  else :
   Ii1IIii11 = str ( o00Oo0oooooo ) + " dB"
  return Ii1IIii11
 def decode_rx_emphasis ( self , eeprom_data , offset , size ) :
  if size == 2 :
   o00Oo0oooooo = ( int ( eeprom_data [ offset ] , 16 ) & 0xf0 ) >> 4
  else :
   o00Oo0oooooo = int ( eeprom_data [ offset ] , 16 ) & 0xf
  if o00Oo0oooooo not in range ( 8 ) :
   Ii1IIii11 = "Reserved"
  else :
   Ii1IIii11 = str ( o00Oo0oooooo ) + " dB"
  return Ii1IIii11
 def decode_rx_amplitude ( self , eeprom_data , offset , size ) :
  if size == 2 :
   o00Oo0oooooo = ( int ( eeprom_data [ offset ] , 16 ) & 0xf0 ) >> 4
  else :
   o00Oo0oooooo = int ( eeprom_data [ offset ] , 16 ) & 0xf
  if o00Oo0oooooo not in range ( 4 ) :
   Ii1IIii11 = "Reserved"
  else :
   II1iIi11 = [ "100-400 mV" , "300-600 mV" , "400-800 mV" , "600-1200 mV" ]
   Ii1IIii11 = II1iIi11 [ o00Oo0oooooo ]
  return Ii1IIii11
 dom_optional_channel_controls = {
 'TX1EQ' : {
 'offset' : 106 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_tx_equalization
 }
 } ,
 'TX2EQ' : {
 'offset' : 106 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_tx_equalization
 }
 } ,
 'TX3EQ' : {
 'offset' : 107 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_tx_equalization
 }
 } ,
 'TX4EQ' : {
 'offset' : 107 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_tx_equalization
 }
 } ,
 'RX1Emphasis' : {
 'offset' : 108 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_emphasis
 }
 } ,
 'RX2Emphasis' : {
 'offset' : 108 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_emphasis
 }
 } ,
 'RX3Emphasis' : {
 'offset' : 109 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_emphasis
 }
 } ,
 'RX4Emphasis' : {
 'offset' : 109 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_emphasis
 }
 } ,
 'RX1Amplitude' : {
 'offset' : 110 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_amplitude
 }
 } ,
 'RX2Amplitude' : {
 'offset' : 110 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_amplitude
 }
 } ,
 'RX3Amplitude' : {
 'offset' : 111 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_amplitude
 }
 } ,
 'RX4Amplitude' : {
 'offset' : 111 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_amplitude
 }
 }
 }
 dom_page3_map = {
 'AwThresholds' : {
 'offset' : 0 ,
 'size' : 72 ,
 'type' : 'nested' ,
 'decode' : dom_aw_thresholds
 } ,
 'OptionalChannelControls' : {
 'offset' : 106 ,
 'size' : 6 ,
 'type' : 'nested' ,
 'decode' : dom_optional_channel_controls
 }
 }
 def __init__ ( self , eeprom_raw_data = None , calibration_type = 1 ) :
  self . _calibration_type = calibration_type
  self . dom_page3 = None
  II111iiiiII = 0
  if eeprom_raw_data != None :
   self . dom_page3 = sffbase . parse ( self , self . dom_page3_map ,
 eeprom_raw_data , II111iiiiII )
 def parse ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_page3_map , eeprom_raw_data , start_pos )
 def dump_pretty ( self ) :
  if self . dom_page3 == None :
   return
  sffbase . dump_pretty ( self , self . dom_page3 )
 def get_data ( self ) :
  return self . dom_page3
 def get_data_pretty ( self ) :
  if self . dom_page3 == None :
   return
  return sffbase . get_data_pretty ( self , self . dom_page3 )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
