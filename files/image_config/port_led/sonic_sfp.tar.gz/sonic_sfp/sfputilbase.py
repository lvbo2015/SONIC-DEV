# sfputilbase.py
#
# Base class for creating platform-specific SFP transceiver interfaces for SONiC
#
from __future__ import print_function
try :
 import abc
 import binascii
 import os
 import re
 import bcmshell
 from sonic_eeprom import eeprom_dts
 from sff8472 import sff8472InterfaceId
 from sff8472 import sff8472Dom
 from sff8436 import sff8436InterfaceId
 from sff8436 import sff8436Dom
 from sff8436 import sff8636DomPage3
except ImportError as e :
 raise ImportError ( "%s - required module not found" % str ( e ) )
XCVR_TYPE_OFFSET = 0
XCVR_TYPE_WIDTH = 1
XCVR_VENDOR_NAME_OFFSET = 20
XCVR_VENDOR_NAME_WIDTH = 16
XCVR_VENDOR_PN_OFFSET = 40
XCVR_VENDOR_PN_WIDTH = 16
XCVR_HW_REV_OFFSET = 56
XCVR_HW_REV_WIDTH_QSFP = 2
XCVR_HW_REV_WIDTH_SFP = 4
XCVR_VENDOR_SN_OFFSET = 68
XCVR_VENDOR_SN_WIDTH = 16
XCVR_DOM_CAPABILITY_OFFSET = 92
XCVR_DOM_CAPABILITY_WIDTH = 1
QSFP_DOM_REV_OFFSET = 1
QSFP_DOM_REV_WIDTH = 1
QSFP_TEMPE_OFFSET = 22
QSFP_TEMPE_WIDTH = 2
QSFP_VLOT_OFFSET = 26
QSFP_VOLT_WIDTH = 2
QSFP_CHANNL_MON_OFFSET = 34
QSFP_CHANNL_MON_WIDTH = 16
QSFP_CHANNL_MON_WITH_TX_POWER_WIDTH = 24
SFP_TEMPE_OFFSET = 96
SFP_TEMPE_WIDTH = 2
SFP_VLOT_OFFSET = 98
SFP_VOLT_WIDTH = 2
SFP_CHANNL_MON_OFFSET = 100
SFP_CHANNL_MON_WIDTH = 6
class SfpUtilError ( Exception ) :
 pass
class DeviceTreeError ( SfpUtilError ) :
 def __init__ ( self , value ) :
  self . value = value
 def __str__ ( self ) :
  return repr ( self . value )
class SfpUtilBase ( object ) :
 __metaclass__ = abc . ABCMeta
 IDENTITY_EEPROM_ADDR = 0x50
 DOM_EEPROM_ADDR = 0x51
 SFP_DEVICE_TYPE = "24c02"
 sfp_ports = [ ]
 logical = [ ]
 logical_to_bcm = { }
 logical_to_physical = { }
 phytab_mappings = { }
 physical_to_logical = { }
 physical_to_phyaddrs = { }
 port_to_i2cbus_mapping = None
 @ abc . abstractproperty
 def port_start ( self ) :
  pass
 @ abc . abstractproperty
 def port_end ( self ) :
  pass
 @ abc . abstractproperty
 def qsfp_ports ( self ) :
  pass
 @ abc . abstractproperty
 def port_to_eeprom_mapping ( self ) :
  pass
 def __init__ ( self ) :
  pass
 def _get_bcm_port ( self , port_num ) :
  o00oOO0 = None
  iI = self . physical_to_logical . get ( port_num )
  if iI is not None and len ( iI ) > 0 :
   o00oOO0 = self . logical_to_bcm . get ( iI [ 0 ] )
  if o00oOO0 is None :
   o00oOO0 = "xe%d" % ( port_num - 1 )
  return o00oOO0
 def _get_port_i2c_adapter_id ( self , port_num ) :
  if len ( self . port_to_i2cbus_mapping ) == 0 :
   return - 1
  return self . port_to_i2cbus_mapping . get ( port_num , - 1 )
 def _add_new_sfp_device ( self , sysfs_sfp_i2c_adapter_path , devaddr ) :
  try :
   Ii1i11IIii1I = "%s/new_device" % sysfs_sfp_i2c_adapter_path
   o0O = open ( Ii1i11IIii1I , "w" )
   O00oO = "%s %s" % ( self . SFP_DEVICE_TYPE , hex ( devaddr ) )
   o0O . write ( O00oO )
   o0O . close ( )
  except Exception as OoOOOOO :
   print ( "Error writing to new device file: %s" % str ( OoOOOOO ) )
   return 1
  else :
   return 0
 def _delete_sfp_device ( self , sysfs_sfp_i2c_adapter_path , devaddr ) :
  try :
   Ii1i11IIii1I = "%s/delete_device" % sysfs_sfp_i2c_adapter_path
   o0O = open ( Ii1i11IIii1I , "w" )
   o0O . write ( devaddr )
   o0O . close ( )
  except Exception as OoOOOOO :
   print ( "Error writing to new device file: %s" % str ( OoOOOOO ) )
   return 1
  else :
   return 0
 def _sfp_eeprom_present ( self , sysfs_sfp_i2c_client_eeprompath , offset ) :
  if not os . path . exists ( sysfs_sfp_i2c_client_eeprompath ) :
   return False
  else :
   try :
    with open ( sysfs_sfp_i2c_client_eeprompath , mode = "rb" , buffering = 0 ) as OOO :
     OOO . seek ( offset )
     OOO . read ( 1 )
   except IOError :
    return False
   except :
    return False
   else :
    return True
 def _get_port_eeprom_path ( self , port_num , devid ) :
  Oo0OoO00oOO0o = "/sys/class/i2c-adapter"
  if port_num in self . port_to_eeprom_mapping . keys ( ) :
   OoOO0oo0o = self . port_to_eeprom_mapping [ port_num ]
  else :
   Oo0OoO00oOO0o = "/sys/class/i2c-adapter"
   Oo0o00 = self . _get_port_i2c_adapter_id ( port_num )
   if Oo0o00 is None :
    print ( "Error getting i2c bus num" )
    return None
   I1ii11iI = "%s/i2c-%s" % ( Oo0OoO00oOO0o ,
 str ( Oo0o00 ) )
   if not os . path . exists ( I1ii11iI ) :
    print ( "Could not find i2c bus %s. Driver not loaded?" % I1ii11iI )
    return None
   ooo0OO = "%s/%s-00%s" % ( I1ii11iI ,
 str ( Oo0o00 ) ,
 hex ( devid ) [ - 2 : ] )
   if not os . path . exists ( ooo0OO ) :
    oooooOoo0ooo = self . _add_new_sfp_device (
 I1ii11iI , devid )
    if oooooOoo0ooo != 0 :
     print ( "Error adding sfp device" )
     return None
   OoOO0oo0o = "%s/eeprom" % ooo0OO
  return OoOO0oo0o
 def _read_eeprom_specific_bytes ( self , sysfsfile_eeprom , offset , num_bytes ) :
  O0oOoOOOoOO = [ ]
  for ii1ii11IIIiiI in range ( 0 , num_bytes ) :
   O0oOoOOOoOO . append ( "0x00" )
  try :
   sysfsfile_eeprom . seek ( offset )
   I1I111 = sysfsfile_eeprom . read ( num_bytes )
  except IOError :
   print ( "Error: reading sysfs file %s" % sysfsfile_eeprom )
   return None
  try :
   for i1 in range ( 0 , num_bytes ) :
    O0oOoOOOoOO [ i1 ] = hex ( ord ( I1I111 [ i1 ] ) ) [ 2 : ] . zfill ( 2 )
  except :
   return None
  return O0oOoOOOoOO
 def _read_eeprom_devid ( self , port_num , devid , offset , num_bytes = 256 ) :
  OoOO0oo0o = self . _get_port_eeprom_path ( port_num , devid )
  if not self . _sfp_eeprom_present ( OoOO0oo0o , offset ) :
   return None
  try :
   iiii = open ( OoOO0oo0o , mode = "rb" , buffering = 0 )
  except IOError :
   print ( "Error: reading sysfs file %s" % OoOO0oo0o )
   return None
  O0oOoOOOoOO = self . _read_eeprom_specific_bytes ( iiii , offset , num_bytes )
  try :
   iiii . close ( )
  except :
   return None
  return O0oOoOOOoOO
 def _is_valid_port ( self , port_num ) :
  if port_num >= self . port_start and port_num <= self . port_end :
   return True
  return False
 def read_porttab_mappings ( self , porttabfile ) :
  III1IiiI = [ ]
  iIi1 = { }
  IIIII11I1IiI = { }
  i1I = { }
  OoOO = 0
  ooOOO0 = ""
  o0o = 1
  O0OOoO00OO0o = 0
  I1111IIIIIi = False
  try :
   oo000o = open ( porttabfile )
  except :
   raise
  I1111IIIIIi = ( os . path . basename ( porttabfile ) == "port_config.ini" )
  o00o0 = [ ]
  for ii in oo000o :
   ii . strip ( )
   if re . search ( "^#" , ii ) is not None :
    o00o0 = ii . split ( ) [ 1 : ]
    continue
   if ( I1111IIIIIi ) :
    oOoooo0O0Oo = ii . split ( ) [ 0 ]
    o00oOO0 = str ( O0OOoO00OO0o )
    if "index" in o00o0 :
     OO0OO0O00oO0 = int ( ii . split ( ) [ o00o0 . index ( "index" ) ] )
    elif len ( ii . split ( ) ) >= 4 :
     OO0OO0O00oO0 = int ( ii . split ( ) [ 3 ] )
    else :
     OO0OO0O00oO0 = oOoooo0O0Oo . split ( "Ethernet" ) . pop ( )
     OO0OO0O00oO0 = int ( OO0OO0O00oO0 . split ( "s" ) . pop ( 0 ) ) / 4
   else :
    ( oOoooo0O0Oo , o00oOO0 ) = ii . split ( "=" ) [ 1 ] . split ( "," ) [ : 2 ]
    OO0OO0O00oO0 = oOoooo0O0Oo . split ( "Ethernet" ) . pop ( )
    OO0OO0O00oO0 = int ( OO0OO0O00oO0 . split ( "s" ) . pop ( 0 ) ) / 4
   if ( ( len ( self . sfp_ports ) > 0 ) and ( OO0OO0O00oO0 not in self . sfp_ports ) ) :
    continue
   if o0o == 1 :
    OoOO = OO0OO0O00oO0
    ooOOO0 = oOoooo0O0Oo
    o0o = 0
   III1IiiI . append ( oOoooo0O0Oo )
   iIi1 [ oOoooo0O0Oo ] = "xe" + o00oOO0
   IIIII11I1IiI [ oOoooo0O0Oo ] = [ OO0OO0O00oO0 ]
   if i1I . get ( OO0OO0O00oO0 ) is None :
    i1I [ OO0OO0O00oO0 ] = [ oOoooo0O0Oo ]
   else :
    i1I [ OO0OO0O00oO0 ] . append (
 oOoooo0O0Oo )
   if ( OO0OO0O00oO0 - OoOO ) > 1 :
    for i1i in range ( OoOO + 1 , OO0OO0O00oO0 ) :
     IIIII11I1IiI [ ooOOO0 ] . append ( i1i )
     if i1I . get ( i1i ) is None :
      i1I [ i1i ] = [ ooOOO0 ]
     else :
      i1I [ i1i ] . append ( ooOOO0 )
   OoOO = OO0OO0O00oO0
   ooOOO0 = oOoooo0O0Oo
   O0OOoO00OO0o += 1
  self . logical = III1IiiI
  self . logical_to_bcm = iIi1
  self . logical_to_physical = IIIII11I1IiI
  self . physical_to_logical = i1I
 def read_phytab_mappings ( self , phytabfile ) :
  III1IiiI = [ ]
  oOOOoo0O0oO = { }
  i1I = { }
  iIII1I111III = { }
  try :
   oo000o = open ( phytabfile )
  except :
   raise
  for ii in oo000o :
   ii = ii . strip ( )
   ii = re . sub ( r"\s+" , " " , ii )
   if len ( ii ) < 4 :
    continue
   if re . search ( "^#" , ii ) is not None :
    continue
   ( ooooo0O0000oo , iI , o00oOO0 , type ) = ii . split ( " " , 3 )
   if re . match ( "xe" , o00oOO0 ) is None :
    continue
   oo0oO = re . findall ( "swp(\d+)s*(\d*)" , iI )
   if oo0oO is not None :
    Oo0O0 = oo0oO . pop ( )
    Ooo0OOoOoO0 = int ( Oo0O0 [ 0 ] )
   else :
    Ooo0OOoOoO0 = iI . split ( "swp" ) . pop ( )
    Ooo0OOoOoO0 = int ( Ooo0OOoOoO0 . split ( "s" ) . pop ( 0 ) )
   if ( ( len ( self . sfp_ports ) > 0 ) and ( Ooo0OOoOoO0 not in self . sfp_ports ) ) :
    continue
   if iI not in III1IiiI :
    III1IiiI . append ( iI )
   if oOOOoo0O0oO . get ( iI ) is None :
    oOOOoo0O0oO [ iI ] = { }
    oOOOoo0O0oO [ iI ] [ 'physicalport' ] = [ ]
    oOOOoo0O0oO [ iI ] [ 'phyid' ] = [ ]
    oOOOoo0O0oO [ iI ] [ 'type' ] = type
   i11i = oOOOoo0O0oO [ iI ] [ 'physicalport' ]
   if ( type == "40G/4" and Ooo0OOoOoO0 in i11i ) :
    ooO = i11i [ - 1 ] + 1
   else :
    ooO = Ooo0OOoOoO0
   if ( ooO not in oOOOoo0O0oO [ iI ] [ 'physicalport' ] ) :
    oOOOoo0O0oO [ iI ] [ 'physicalport' ] . append ( ooO )
   oOOOoo0O0oO [ iI ] [ 'phyid' ] . append ( ooooo0O0000oo )
   oOOOoo0O0oO [ iI ] [ 'bcmport' ] = o00oOO0
   if i1I . get ( ooO ) is None :
    i1I [ ooO ] = [ ]
   i1I [ ooO ] . append ( iI )
   if iIII1I111III . get ( ooO ) is None :
    iIII1I111III [ ooO ] = [ ]
   iIII1I111III [ ooO ] . append ( ooooo0O0000oo )
  self . logical = III1IiiI
  self . phytab_mappings = oOOOoo0O0oO
  self . physical_to_logical = i1I
  self . physical_to_phyaddrs = iIII1I111III
 def get_physical_to_logical ( self , port_num ) :
  return self . physical_to_logical [ port_num ]
 def get_logical_to_physical ( self , logical_port ) :
  return self . logical_to_physical [ logical_port ]
 def is_logical_port ( self , port ) :
  if port in self . logical :
   return 1
  else :
   return 0
 def is_logical_port_ganged_40_by_4 ( self , logical_port ) :
  II1i11I = self . logical_to_physical [ logical_port ]
  if len ( II1i11I ) > 1 :
   return 1
  else :
   return 0
 def is_physical_port_ganged_40_by_4 ( self , port_num ) :
  iI = self . get_physical_to_logical ( port_num )
  if iI is not None :
   return self . is_logical_port_ganged_40_by_4 ( iI [ 0 ] )
  return 0
 def get_physical_port_phyid ( self , physical_port ) :
  return self . physical_to_phyaddrs [ physical_port ]
 def get_40_by_4_gangport_phyid ( self , logical_port ) :
  i1Iii11Ii1i1 = self . phytab_mappings [ logical_port ] [ 'phyid' ]
  if i1Iii11Ii1i1 is not None :
   return i1Iii11Ii1i1 [ 0 ]
 def is_valid_sfputil_port ( self , port ) :
  if port . startswith ( "" ) :
   if self . is_logical_port ( port ) :
    return 1
   else :
    return 0
  else :
   return 0
 def read_port_mappings ( self ) :
  if self . port_to_eeprom_mapping is None or self . port_to_i2cbus_mapping is None :
   self . read_port_to_eeprom_mapping ( )
   self . read_port_to_i2cbus_mapping ( )
 def read_port_to_eeprom_mapping ( self ) :
  Ii = "/sys/class/eeprom_dev"
  self . port_to_eeprom_mapping = { }
  for o0O0Oo in [ os . path . join ( Ii , Ooo0O0oooo ) for Ooo0O0oooo in os . listdir ( Ii ) ] :
   iiI = open ( os . path . join ( o0O0Oo , "label" ) , "r" ) . read ( ) . strip ( )
   if iiI . startswith ( "port" ) :
    oO = int ( iiI [ 4 : ] )
    self . port_to_eeprom_mapping [ oO ] = os . path . join ( o0O0Oo , "device" , "eeprom" )
 def read_port_to_i2cbus_mapping ( self ) :
  if self . port_to_i2cbus_mapping is not None and len ( self . port_to_i2cbus_mapping ) > 0 :
   return
  self . eep_dict = eeprom_dts . get_dev_attr_from_dtb ( [ 'sfp' ] )
  if len ( self . eep_dict ) == 0 :
   return
  o0oO000oo = [ ]
  self . port_to_i2cbus_mapping = { }
  o00o0II1I = self . port_start
  for II1I1I1Ii , OOOOoO00o0O in sorted ( self . eep_dict . iteritems ( ) ) :
   I1I1I1IIi1III = OOOOoO00o0O . get ( "dev-id" )
   if I1I1I1IIi1III is None :
    raise DeviceTreeError ( "No 'dev-id' attribute found in attr: %s" % repr ( OOOOoO00o0O ) )
   if I1I1I1IIi1III in o0oO000oo :
    continue
   o0oO000oo . append ( I1I1I1IIi1III )
   self . port_to_i2cbus_mapping [ o00o0II1I ] = I1I1I1IIi1III
   o00o0II1I += 1
   if o00o0II1I > self . port_end :
    break
 def get_eeprom_raw ( self , port_num ) :
  return self . _read_eeprom_devid ( port_num , self . IDENTITY_EEPROM_ADDR , 0 )
 def get_eeprom_dom_raw ( self , port_num ) :
  if port_num in self . qsfp_ports :
   return None
  else :
   return self . _read_eeprom_devid ( port_num , self . DOM_EEPROM_ADDR , 0 )
 def get_eeprom_raw_by_page ( self , port_num , page_num = 0 , num_bytes = 0 ) :
  iii11I = 128
  I1Iii1 = 5
  if port_num not in self . qsfp_ports :
   return None
  if page_num not in range ( I1Iii1 ) :
   return None
  ii1ii111 = I1Iii1 * iii11I if num_bytes == 0 else num_bytes
  I111i1i1111 = page_num * iii11I
  return self . _read_eeprom_devid ( port_num , self . IDENTITY_EEPROM_ADDR ,
 I111i1i1111 , ii1ii111 )
 def get_eeprom_dom_chan_mon ( self , port_num ) :
  I1ii11 = { }
  oOoOoOoo0 = self . get_transceiver_dom_info_dict ( port_num )
  if oOoOoOoo0 is not None and 'tx1power' in oOoOoOoo0 :
   III1ii1I = {
 'rx1power' : 'RX1Power' , 'rx2power' : 'RX2Power' ,
 'rx3power' : 'RX3Power' , 'rx4power' : 'RX4Power' ,
 'tx1power' : 'TX1Power' , 'tx2power' : 'TX2Power' ,
 'tx3power' : 'TX3Power' , 'tx4power' : 'TX4Power' ,
 'tx1bias' : 'TX1Bias' , 'tx2bias' : 'TX2Bias' ,
 'tx3bias' : 'TX3Bias' , 'tx4bias' : 'TX4Bias'
 }
   Ii1i1iI = III1ii1I . keys ( )
   for IIiI1 in Ii1i1iI :
    if IIiI1 in oOoOoOoo0 :
     I1ii11 [ III1ii1I [ IIiI1 ] ] = oOoOoOoo0 [ IIiI1 ]
   if len ( I1ii11 ) != len ( Ii1i1iI ) :
    I1ii11 = { }
  return I1ii11
 def get_eeprom_dict ( self , port_num ) :
  i1OO0oOOoo = { }
  Oo000ooOOO = self . get_eeprom_raw ( port_num )
  Ii11i1I11i = self . get_eeprom_dom_raw ( port_num )
  if Oo000ooOOO is None :
   return None
  if port_num in self . qsfp_ports :
   IiIi1iIIi1 = sff8436InterfaceId ( Oo000ooOOO )
   if IiIi1iIIi1 is not None :
    i1OO0oOOoo [ 'interface' ] = IiIi1iIIi1 . get_data_pretty ( )
    O0OoO0ooOO0o = i1OO0oOOoo [ 'interface' ]
    if O0OoO0ooOO0o is not None and 'data' in O0OoO0ooOO0o and 'TypeOfTransceiver' in O0OoO0ooOO0o [ 'data' ] :
     oOi11iI11iIiIi = O0OoO0ooOO0o [ 'data' ] [ 'TypeOfTransceiver' ]
     if oOi11iI11iIiIi != None and oOi11iI11iIiIi . find ( 'DAC' ) != - 1 :
      return i1OO0oOOoo
   OoO = sff8436Dom ( Oo000ooOOO )
   if OoO is not None :
    i1OO0oOOoo [ 'dom' ] = OoO . get_data_pretty ( )
    if 'data' in i1OO0oOOoo [ 'dom' ] and 'ChannelMonitorValues' in i1OO0oOOoo [ 'dom' ] [ 'data' ] :
     I1ii11 = self . get_eeprom_dom_chan_mon ( port_num )
     i1OO0oOOoo [ 'dom' ] [ 'data' ] [ 'ChannelMonitorValues' ] = I1ii11
     II1i = self . get_eeprom_raw_by_page ( port_num , 4 )
     Ii1IIIIi1ii1I = sff8636DomPage3 ( II1i )
     if Ii1IIIIi1ii1I is not None :
      IiiIiI1Ii1i = Ii1IIIIi1ii1I . get_data_pretty ( )
      if IiiIiI1Ii1i is not None and 'data' in IiiIiI1Ii1i :
       for i1iIi in IiiIiI1Ii1i [ 'data' ] :
        i1OO0oOOoo [ 'dom' ] [ 'data' ] [ i1iIi ] = IiiIiI1Ii1i [ 'data' ] [ i1iIi ]
   return i1OO0oOOoo
  IiIi1iIIi1 = sff8472InterfaceId ( Oo000ooOOO )
  if IiIi1iIIi1 is not None :
   i1OO0oOOoo [ 'interface' ] = IiIi1iIIi1 . get_data_pretty ( )
   IIiii11i = IiIi1iIIi1 . get_calibration_type ( )
   O0OoO0ooOO0o = i1OO0oOOoo [ 'interface' ]
   if O0OoO0ooOO0o is not None and 'data' in O0OoO0ooOO0o and 'TypeOfTransceiver' in O0OoO0ooOO0o [ 'data' ] :
    oOi11iI11iIiIi = O0OoO0ooOO0o [ 'data' ] [ 'TypeOfTransceiver' ]
    if oOi11iI11iIiIi is not None and oOi11iI11iIiIi . find ( 'DAC' ) != - 1 :
     return i1OO0oOOoo
  if Ii11i1I11i is not None :
   OoO = sff8472Dom ( Ii11i1I11i , IIiii11i )
   if OoO is not None :
    i1OO0oOOoo [ 'dom' ] = OoO . get_data_pretty ( )
  return i1OO0oOOoo
 def get_transceiver_info_dict ( self , port_num ) :
  oOO00O0Ooooo00 = { }
  if port_num in self . qsfp_ports :
   I111i1i1111 = 128
   ii111I11iI = XCVR_HW_REV_WIDTH_QSFP
  else :
   I111i1i1111 = 0
   ii111I11iI = XCVR_HW_REV_WIDTH_SFP
  Ooooooo = self . _get_port_eeprom_path ( port_num , self . IDENTITY_EEPROM_ADDR )
  if not self . _sfp_eeprom_present ( Ooooooo , 0 ) :
   print ( "Error, file not exist %s" % Ooooooo )
   return None
  try :
   iiii = open ( Ooooooo , mode = "rb" , buffering = 0 )
  except IOError :
   print ( "Error: reading sysfs file %s" % Ooooooo )
   return None
  IiIi1iIIi1 = sff8436InterfaceId ( )
  if IiIi1iIIi1 is None :
   print ( "Error: sfp_object open failed" )
   return None
  iI1iIIIi1i = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + XCVR_TYPE_OFFSET ) , XCVR_TYPE_WIDTH )
  if iI1iIIIi1i is not None :
   ooo = IiIi1iIIi1 . parse_sfp_type ( iI1iIIIi1i , 0 )
  else :
   return None
  iIiiiii1i = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + XCVR_VENDOR_NAME_OFFSET ) , XCVR_VENDOR_NAME_WIDTH )
  if iIiiiii1i is not None :
   iiIi1IIiI = IiIi1iIIi1 . parse_vendor_name ( iIiiiii1i , 0 )
  else :
   return None
  i1II11II = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + XCVR_VENDOR_PN_OFFSET ) , XCVR_VENDOR_PN_WIDTH )
  if i1II11II is not None :
   oOo00O000Oo0 = IiIi1iIIi1 . parse_vendor_pn ( i1II11II , 0 )
  else :
   return None
  oOooO0 = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + XCVR_HW_REV_OFFSET ) , ii111I11iI )
  if oOooO0 is not None :
   OOOoO000 = IiIi1iIIi1 . parse_vendor_rev ( oOooO0 , 0 )
  else :
   return None
  oOOOoo = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + XCVR_VENDOR_SN_OFFSET ) , XCVR_VENDOR_SN_WIDTH )
  if oOOOoo is not None :
   Ii1ii111i1 = IiIi1iIIi1 . parse_vendor_sn ( oOOOoo , 0 )
  else :
   return None
  try :
   iiii . close ( )
  except IOError :
   print ( "Error: closing sysfs file %s" % Ooooooo )
   return None
  oOO00O0Ooooo00 [ 'type' ] = ooo [ 'data' ] [ 'type' ] [ 'value' ]
  oOO00O0Ooooo00 [ 'manufacturename' ] = iiIi1IIiI [ 'data' ] [ 'Vendor Name' ] [ 'value' ]
  oOO00O0Ooooo00 [ 'modelname' ] = oOo00O000Oo0 [ 'data' ] [ 'Vendor PN' ] [ 'value' ]
  oOO00O0Ooooo00 [ 'hardwarerev' ] = OOOoO000 [ 'data' ] [ 'Vendor Rev' ] [ 'value' ]
  oOO00O0Ooooo00 [ 'serialnum' ] = Ii1ii111i1 [ 'data' ] [ 'Vendor SN' ] [ 'value' ]
  return oOO00O0Ooooo00
 def get_transceiver_dom_info_dict ( self , port_num ) :
  IiI11i1IIiiI = { }
  if port_num in self . qsfp_ports :
   I111i1i1111 = 0
   I1iIiI11I1 = 128
   Ooooooo = self . _get_port_eeprom_path ( port_num , self . IDENTITY_EEPROM_ADDR )
   if not self . _sfp_eeprom_present ( Ooooooo , 0 ) :
    return None
   try :
    iiii = open ( Ooooooo , mode = "rb" , buffering = 0 )
   except IOError :
    print ( "Error: reading sysfs file %s" % Ooooooo )
    return None
   OoO = sff8436Dom ( )
   if OoO is None :
    return None
   IiIi1iIIi1 = sff8436InterfaceId ( )
   if IiIi1iIIi1 is None :
    return None
   I1iii = self . _read_eeprom_specific_bytes ( iiii , ( I1iIiI11I1 + XCVR_DOM_CAPABILITY_OFFSET ) , XCVR_DOM_CAPABILITY_WIDTH )
   if I1iii is not None :
    oO0o0O0Ooo0o = IiIi1iIIi1 . parse_qsfp_dom_capability ( I1iii , 0 )
   else :
    return None
   ooOoo0o0O = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + QSFP_TEMPE_OFFSET ) , QSFP_TEMPE_WIDTH )
   if ooOoo0o0O is not None :
    oOO0OooOo = OoO . parse_temperature ( ooOoo0o0O , 0 )
   else :
    return None
   Ii1II = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + QSFP_VLOT_OFFSET ) , QSFP_VOLT_WIDTH )
   if Ii1II is not None :
    O0Oo00 = OoO . parse_voltage ( Ii1II , 0 )
   else :
    return None
   oOo0oO = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + QSFP_DOM_REV_OFFSET ) , QSFP_DOM_REV_WIDTH )
   if oOo0oO is not None :
    IIi1IIIIi = OoO . parse_sfp_dom_rev ( oOo0oO , 0 )
   else :
    return None
   IiI11i1IIiiI [ 'temperature' ] = oOO0OooOo [ 'data' ] [ 'Temperature' ] [ 'value' ]
   IiI11i1IIiiI [ 'voltage' ] = O0Oo00 [ 'data' ] [ 'Vcc' ] [ 'value' ]
   iiIiiii1i1i1i = { }
   OOOO = IIi1IIIIi [ 'data' ] [ 'dom_rev' ] [ 'value' ]
   ooO0oO00O0o = oO0o0O0Ooo0o [ 'data' ] [ 'Tx_power_support' ] [ 'value' ]
   if ( OOOO [ 0 : 8 ] != 'SFF-8636' or ( OOOO [ 0 : 8 ] == 'SFF-8636' and ooO0oO00O0o != 'On' ) ) :
    ooOO00oOOo000 = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + QSFP_CHANNL_MON_OFFSET ) , QSFP_CHANNL_MON_WIDTH )
    if ooOO00oOOo000 is not None :
     iiIiiii1i1i1i = OoO . parse_channel_monitor_params ( ooOO00oOOo000 , 0 )
    else :
     return None
    IiI11i1IIiiI [ 'tx1power' ] = 'N/A'
    IiI11i1IIiiI [ 'tx2power' ] = 'N/A'
    IiI11i1IIiiI [ 'tx3power' ] = 'N/A'
    IiI11i1IIiiI [ 'tx4power' ] = 'N/A'
   else :
    ooOO00oOOo000 = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + QSFP_CHANNL_MON_OFFSET ) , QSFP_CHANNL_MON_WITH_TX_POWER_WIDTH )
    if ooOO00oOOo000 is not None :
     iiIiiii1i1i1i = OoO . parse_channel_monitor_params_with_tx_power ( ooOO00oOOo000 , 0 )
    else :
     return None
    IiI11i1IIiiI [ 'tx1power' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX1Power' ] [ 'value' ]
    IiI11i1IIiiI [ 'tx2power' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX2Power' ] [ 'value' ]
    IiI11i1IIiiI [ 'tx3power' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX3Power' ] [ 'value' ]
    IiI11i1IIiiI [ 'tx4power' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX4Power' ] [ 'value' ]
   try :
    iiii . close ( )
   except IOError :
    print ( "Error: closing sysfs file %s" % Ooooooo )
    return None
   IiI11i1IIiiI [ 'temperature' ] = oOO0OooOo [ 'data' ] [ 'Temperature' ] [ 'value' ]
   IiI11i1IIiiI [ 'voltage' ] = O0Oo00 [ 'data' ] [ 'Vcc' ] [ 'value' ]
   IiI11i1IIiiI [ 'rx1power' ] = iiIiiii1i1i1i [ 'data' ] [ 'RX1Power' ] [ 'value' ]
   IiI11i1IIiiI [ 'rx2power' ] = iiIiiii1i1i1i [ 'data' ] [ 'RX2Power' ] [ 'value' ]
   IiI11i1IIiiI [ 'rx3power' ] = iiIiiii1i1i1i [ 'data' ] [ 'RX3Power' ] [ 'value' ]
   IiI11i1IIiiI [ 'rx4power' ] = iiIiiii1i1i1i [ 'data' ] [ 'RX4Power' ] [ 'value' ]
   IiI11i1IIiiI [ 'tx1bias' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX1Bias' ] [ 'value' ]
   IiI11i1IIiiI [ 'tx2bias' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX2Bias' ] [ 'value' ]
   IiI11i1IIiiI [ 'tx3bias' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX3Bias' ] [ 'value' ]
   IiI11i1IIiiI [ 'tx4bias' ] = iiIiiii1i1i1i [ 'data' ] [ 'TX4Bias' ] [ 'value' ]
  else :
   I111i1i1111 = 256
   Ooooooo = self . _get_port_eeprom_path ( port_num , self . DOM_EEPROM_ADDR )
   if not self . _sfp_eeprom_present ( Ooooooo , 0 ) :
    return None
   try :
    iiii = open ( Ooooooo , mode = "rb" , buffering = 0 )
   except IOError :
    print ( "Error: reading sysfs file %s" % Ooooooo )
    return None
   OoO = sff8472Dom ( )
   if OoO is None :
    return None
   ooOoo0o0O = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + SFP_TEMPE_OFFSET ) , SFP_TEMPE_WIDTH )
   if ooOoo0o0O is not None :
    oOO0OooOo = OoO . parse_temperature ( ooOoo0o0O , 0 )
   else :
    return None
   Ii1II = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + SFP_VLOT_OFFSET ) , SFP_VOLT_WIDTH )
   if Ii1II is not None :
    O0Oo00 = OoO . parse_voltage ( Ii1II , 0 )
   else :
    return None
   ooOO00oOOo000 = self . _read_eeprom_specific_bytes ( iiii , ( I111i1i1111 + SFP_CHANNL_MON_OFFSET ) , SFP_CHANNL_MON_WIDTH )
   if ooOO00oOOo000 is not None :
    iiIiiii1i1i1i = OoO . parse_channel_monitor_params ( ooOO00oOOo000 , 0 )
   else :
    return None
   try :
    iiii . close ( )
   except IOError :
    print ( "Error: closing sysfs file %s" % Ooooooo )
    return None
   IiI11i1IIiiI [ 'temperature' ] = oOO0OooOo [ 'data' ] [ 'Temperature' ] [ 'value' ]
   IiI11i1IIiiI [ 'voltage' ] = O0Oo00 [ 'data' ] [ 'Vcc' ] [ 'value' ]
   IiI11i1IIiiI [ 'rx1power' ] = iiIiiii1i1i1i [ 'data' ] [ 'RXPower' ] [ 'value' ]
   IiI11i1IIiiI [ 'rx2power' ] = 'N/A'
   IiI11i1IIiiI [ 'rx3power' ] = 'N/A'
   IiI11i1IIiiI [ 'rx4power' ] = 'N/A'
   IiI11i1IIiiI [ 'tx1bias' ] = iiIiiii1i1i1i [ 'data' ] [ 'TXBias' ] [ 'value' ]
   IiI11i1IIiiI [ 'tx2bias' ] = 'N/A'
   IiI11i1IIiiI [ 'tx3bias' ] = 'N/A'
   IiI11i1IIiiI [ 'tx4bias' ] = 'N/A'
   IiI11i1IIiiI [ 'tx1power' ] = iiIiiii1i1i1i [ 'data' ] [ 'TXPower' ] [ 'value' ]
   IiI11i1IIiiI [ 'tx2power' ] = 'N/A'
   IiI11i1IIiiI [ 'tx3power' ] = 'N/A'
   IiI11i1IIiiI [ 'tx4power' ] = 'N/A'
  return IiI11i1IIiiI
 @ abc . abstractmethod
 def get_presence ( self , port_num ) :
  return
 @ abc . abstractmethod
 def get_low_power_mode ( self , port_num ) :
  return
 @ abc . abstractmethod
 def set_low_power_mode ( self , port_num , lpmode ) :
  return
 @ abc . abstractmethod
 def reset ( self , port_num ) :
  return
 @ abc . abstractmethod
 def get_transceiver_change_event ( self , timeout = 0 ) :
  return
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
