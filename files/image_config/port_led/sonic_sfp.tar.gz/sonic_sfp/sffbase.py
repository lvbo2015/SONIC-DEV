#! /usr/bin/env python
#----------------------------------------------------------------------------
# sffbase class for sff8436 and sff8472
#----------------------------------------------------------------------------
from __future__ import print_function
try :
 import fcntl
 import struct
 import sys
 import time
 import binascii
 import os
 import getopt
 import types
 from math import log10
except ImportError as e :
 raise ImportError ( str ( e ) + "- required module not found" )
class sffbase ( object ) :
 _indent = '\t'
 def inc_indent ( self ) :
  self . _indent += '\t'
 def dec_indent ( self ) :
  self . _indent = self . _indent [ : - 1 ]
 def convert_hex_to_string ( self , arr , start , end ) :
  try :
   o0oO0 = ''
   for oo00 in range ( start , end ) :
    o0oO0 += arr [ oo00 ]
   return str . strip ( binascii . unhexlify ( o0oO0 ) )
  except Exception as o00 :
   return str ( o00 )
 def convert_date_to_string ( self , eeprom_data , offset , size ) :
  try :
   Ii1IIii11 = 0
   Oooo0000 = 2
   i11 = 4
   I11 = 6
   o0o0Oo0oooo0 = self . convert_hex_to_string ( eeprom_data , offset , offset + size )
   oO0O0o0o0 = "20" + o0o0Oo0oooo0 [ Ii1IIii11 : Oooo0000 ] + "-" + o0o0Oo0oooo0 [ Oooo0000 : i11 ] + "-" + o0o0Oo0oooo0 [ i11 : I11 ] + " " + o0o0Oo0oooo0 [ I11 : size ]
  except Exception as o00 :
   oO0O0o0o0 = str ( o00 )
  return oO0O0o0o0
 def test_bit ( self , n , bitpos ) :
  try :
   iIiiI1 = 1 << bitpos
   if ( n & iIiiI1 ) == 0 :
    return 0
   else :
    return 1
  except :
   return - 1
 def twos_comp ( self , num , bits ) :
  try :
   if ( ( num & ( 1 << ( bits - 1 ) ) ) != 0 ) :
    num = num - ( 1 << bits )
   return num
  except :
   return 0
 def mw_to_dbm ( self , mW ) :
  if mW == 0 :
   return float ( "-inf" )
  elif mW < 0 :
   return float ( "NaN" )
  return 10. * log10 ( mW )
 def power_in_dbm_str ( self , mW ) :
  return "%.4f%s" % ( self . mw_to_dbm ( mW ) , "dBm" )
 def parse_sff_element ( self , eeprom_data , eeprom_ele , start_pos ) :
  O0O00Ooo = None
  OOoooooO = eeprom_ele . get ( 'offset' ) + start_pos
  i1iIIIiI1I = eeprom_ele . get ( 'size' )
  type = eeprom_ele . get ( 'type' )
  OOoO000O0OO = eeprom_ele . get ( 'decode' ) ;
  if type == 'enum' :
   O0O00Ooo = OOoO000O0OO . get ( str ( eeprom_data [ OOoooooO ] ) , 'Unknown' )
  elif type == 'bitmap' :
   O00oooo0O = { }
   for IiI1i11iii1 , oo0Oo00Oo0 in sorted ( OOoO000O0OO . iteritems ( ) ) :
    oOOO00o = oo0Oo00Oo0 . get ( 'offset' ) + start_pos
    O0O00o0OOO0 = oo0Oo00Oo0 . get ( 'bit' )
    Ii1iIIIi1ii = oo0Oo00Oo0 . get ( 'value' )
    o0oo0o0O00OO = int ( eeprom_data [ oOOO00o ] , 16 )
    o0oO = self . test_bit ( o0oo0o0O00OO , O0O00o0OOO0 )
    if Ii1iIIIi1ii != None :
     if o0oO == Ii1iIIIi1ii :
      O0O00Ooo = IiI1i11iii1
      break
    elif o0oO == 1 :
     O0O00Ooo = IiI1i11iii1
     break
  elif type == 'bitvalue' :
   oO00 = eeprom_ele . get ( 'bit' )
   o0oo0o0O00OO = int ( eeprom_data [ OOoooooO ] , 16 )
   ooo = self . test_bit ( o0oo0o0O00OO , oO00 )
   O0O00Ooo = [ 'Off' , 'On' ] [ ooo ]
  elif type == 'func' :
   O0O00Ooo = OOoO000O0OO [ 'func' ] ( self , eeprom_data ,
 OOoooooO , i1iIIIiI1I )
  elif type == 'str' :
   O0O00Ooo = self . convert_hex_to_string ( eeprom_data , OOoooooO ,
 OOoooooO + i1iIIIiI1I )
   if O0O00Ooo is not None :
    for OooOooooOOoo0 in range ( len ( O0O00Ooo ) ) :
     if O0O00Ooo [ OooOooooOOoo0 ] == '\xff' or O0O00Ooo [ OooOooooOOoo0 ] == '\xfe' :
      O0O00Ooo = ""
      break
  elif type == 'int' :
   o0oo0o0O00OO = int ( eeprom_data [ OOoooooO ] , 16 )
   if o0oo0o0O00OO != 0 :
    O0O00Ooo = o0oo0o0O00OO
  elif type == 'date' :
   O0O00Ooo = self . convert_date_to_string ( eeprom_data , OOoooooO ,
 i1iIIIiI1I )
  elif type == 'hex' :
   O0O00Ooo = '-' . join ( eeprom_data [ OOoooooO : OOoooooO + i1iIIIiI1I ] )
  return O0O00Ooo
 def parse_sff ( self , eeprom_map , eeprom_data , start_pos ) :
  I11II = { }
  for iII1IIIiI1I1i , O0o0Ooo in sorted ( eeprom_map . iteritems ( ) ) :
   type = O0o0Ooo . get ( 'type' )
   Oo0O0O0ooO0O = { }
   Oo0O0O0ooO0O [ 'outtype' ] = O0o0Ooo . get ( 'outtype' )
   Oo0O0O0ooO0O [ 'short_name' ] = O0o0Ooo . get ( 'short_name' )
   if type != 'nested' :
    o0oo0o0O00OO = self . parse_sff_element ( eeprom_data ,
 O0o0Ooo , start_pos )
   else :
    oo000OO00Oo = O0o0Ooo . get ( 'decode' )
    o0oo0o0O00OO = self . parse_sff ( oo000OO00Oo ,
 eeprom_data , start_pos )
   if o0oo0o0O00OO != None :
    Oo0O0O0ooO0O [ 'value' ] = o0oo0o0O00OO
    I11II [ iII1IIIiI1I1i ] = Oo0O0O0ooO0O
  return I11II
 def parse ( self , eeprom_map , eeprom_data , start_pos ) :
  I11II = { }
  i1I11i1I = { }
  I11II = self . parse_sff ( eeprom_map , eeprom_data , start_pos )
  i1I11i1I [ 'version' ] = self . version
  i1I11i1I [ 'data' ] = I11II
  return i1I11i1I
 def get_data_pretty_dict ( self , indict ) :
  I11II = { }
  for i11i1I1 , ii1I in sorted ( indict . iteritems ( ) ) :
   O0O00Ooo = ii1I . get ( 'value' )
   if type ( O0O00Ooo ) == types . DictType :
    I11II [ i11i1I1 ] = sffbase . get_data_pretty_dict (
 self , O0O00Ooo )
   else :
    I11II [ i11i1I1 ] = O0O00Ooo
  return I11II
 def get_data_pretty ( self , indata ) :
  i1I11i1I = { }
  i1I11i1I [ 'version' ] = indata . get ( 'version' )
  i1I11i1I [ 'data' ] = self . get_data_pretty_dict ( indata . get (
 'data' ) )
  return i1I11i1I
 def dump_pretty ( self , indict ) :
  for i11i1I1 , ii1I in sorted ( indict . iteritems ( ) ) :
   if type ( ii1I ) == types . DictType :
    print ( self . _indent , i11i1I1 , ': ' )
    self . inc_indent ( )
    sff8472 . dump_pretty ( self , ii1I )
    self . dec_indent ( )
   elif type ( ii1I ) == types . ListType :
    if len ( ii1I ) == 1 :
     print ( self . _indent , i11i1I1 , ': ' , ii1I . pop ( ) )
    else :
     print ( self . _indent , i11i1I1 , ': ' )
     self . inc_indent ( )
     for i1iIIIi1i in ii1I :
      print ( self . _indent , i1iIIIi1i )
     self . dec_indent ( )
   else :
    print ( self . _indent , i11i1I1 , ': ' , ii1I )
 def handle_xcvr_type ( self , type , intf_data ) :
  if type is not None and type . find ( "DAC" ) == - 1 :
   II111iiiI1Ii = [ 'AliPN' , 'LengthCable(UnitsOfmm)' ,
 'CableDiameter(UnitsOfmm)' ,
 'LaneBitRate(UnitsOfGbps)' ]
   for o0O0OOO0Ooo in II111iiiI1Ii :
    if o0O0OOO0Ooo in intf_data :
     intf_data . pop ( o0O0OOO0Ooo )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
