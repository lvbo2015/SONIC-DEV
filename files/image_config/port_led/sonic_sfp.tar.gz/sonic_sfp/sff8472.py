#! /usr/bin/env python
#--------------------------------------------------------------------------
#
# Copyright 2012 Cumulus Networks, inc  all rights reserved
#
#--------------------------------------------------------------------------
from __future__ import print_function
try :
 import fcntl
 import struct
 import sys
 import time
 import binascii
 import os
 import getopt
 import types
 from math import log10
 from sffbase import sffbase
except ImportError as e :
 raise ImportError ( str ( e ) + "- required module not found" )
class sff8472InterfaceId ( sffbase ) :
 version = '1.0'
 transceiver_codes = { '10GEthernetComplianceCode' :
 { 'offset' : 3 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : { '10G Base-ER' :
 { 'offset' : 3 ,
 'bit' : 7 } ,
 '10G Base-LRM' :
 { 'offset' : 3 ,
 'bit' : 6 } ,
 '10G Base-LR' :
 { 'offset' : 3 ,
 'bit' : 5 } ,
 '10G Base-SR' :
 { 'offset' : 3 ,
 'bit' : 4 } } } ,
 'InfinibandComplianceCode' :
 { 'offset' : 3 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : { '1X SX' :
 { 'offset' : 3 ,
 'bit' : 3 } ,
 '1X LX' :
 { 'offset' : 3 ,
 'bit' : 2 } ,
 '1X Copper Active' :
 { 'offset' : 3 ,
 'bit' : 1 } ,
 '1X Copper Passive' :
 { 'offset' : 3 ,
 'bit' : 0 } } } ,
 'ESCONComplianceCodes' :
 { 'offset' : 4 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : { 'ESCON MMF, 1310nm LED' :
 { 'offset' : 4 ,
 'bit' : 7 } ,
 'ESCON SMF, 1310nm Laser' :
 { 'offset' : 4 ,
 'bit' : 6 } } } ,
 'SONETComplianceCodes' :
 { 'offset' : 4 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' : { 'OC-192, short reach' :
 { 'offset' : 4 ,
 'bit' : 5 } ,
 'SONET reach specifier bit 1' :
 { 'offset' : 4 ,
 'bit' : 4 } ,
 'SONET reach specifier bit 2' :
 { 'offset' : 4 ,
 'bit' : 3 } ,
 'OC-48, long reach' :
 { 'offset' : 4 ,
 'bit' : 2 } ,
 'OC-48, intermediate reach' :
 { 'offset' : 4 ,
 'bit' : 1 } ,
 'OC-48, short reach' :
 { 'offset' : 4 ,
 'bit' : 0 } ,
 'OC-12, single mode, long reach' :
 { 'offset' : 5 ,
 'bit' : 6 } ,
 'OC-12, single mode, inter reach' :
 { 'offset' : 5 ,
 'bit' : 5 } ,
 'OC-12, short reach' :
 { 'offset' : 5 ,
 'bit' : 4 } ,
 'OC-3, single mode, long reach' :
 { 'offset' : 5 ,
 'bit' : 2 } ,
 'OC-3, single mode, inter reach' :
 { 'offset' : 5 ,
 'bit' : 1 } ,
 'OC-3, short reach' :
 { 'offset' : 5 ,
 'bit' : 0 } } } ,
 'EthernetComplianceCodes' :
 { 'offset' : 6 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' : {
 'BASE-PX' :
 { 'offset' : 6 ,
 'bit' : 7 } ,
 'BASE-BX10' :
 { 'offset' : 6 ,
 'bit' : 6 } ,
 '100BASE-FX' :
 { 'offset' : 6 ,
 'bit' : 5 } ,
 '100BASE-LX/LX10' :
 { 'offset' : 6 ,
 'bit' : 4 } ,
 '1000BASE-T' :
 { 'offset' : 6 ,
 'bit' : 3 } ,
 '1000BASE-CX' :
 { 'offset' : 6 ,
 'bit' : 2 } ,
 '1000BASE-LX' :
 { 'offset' : 6 ,
 'bit' : 1 } ,
 '1000BASE-SX' :
 { 'offset' : 6 ,
 'bit' : 0 } } } ,
 'FibreChannelLinkLength' :
 { 'offset' : 7 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' :
 { 'very long distance (V)' :
 { 'offset' : 7 ,
 'bit' : 7 } ,
 'short distance (S)' :
 { 'offset' : 7 ,
 'bit' : 6 } ,
 'Intermediate distance (I)' :
 { 'offset' : 7 ,
 'bit' : 5 } ,
 'Long distance (L)' :
 { 'offset' : 7 ,
 'bit' : 4 } ,
 'medium distance (M)' :
 { 'offset' : 7 ,
 'bit' : 3 } } } ,
 'FibreChannelTechnology' :
 { 'offset' : 7 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' :
 { 'Shortwave laser, linear Rx (SA)' :
 { 'offset' : 7 ,
 'bit' : 2 } ,
 'Longwave Laser (LC)' :
 { 'offset' : 7 ,
 'bit' : 1 } ,
 'Electrical inter-enclosure (EL)' :
 { 'offset' : 7 ,
 'bit' : 0 } ,
 'Electrical intra-enclosure (EL)' :
 { 'offset' : 8 ,
 'bit' : 7 } ,
 'Shortwave laser w/o OFC (SN)' :
 { 'offset' : 8 ,
 'bit' : 6 } ,
 'Shortwave laser with OFC (SL)' :
 { 'offset' : 8 ,
 'bit' : 5 } ,
 'Longwave laser (LL)' :
 { 'offset' : 8 ,
 'bit' : 4 } } } ,
 'SFP+CableTechnology' :
 { 'offset' : 7 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' :
 { 'Active Cable' :
 { 'offset' : 8 ,
 'bit' : 3 } ,
 'Passive Cable' :
 { 'offset' : 8 ,
 'bit' : 2 } } } ,
 'FibreChannelTransmissionMedia' :
 { 'offset' : 7 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' :
 { 'Twin Axial Pair (TW)' :
 { 'offset' : 9 ,
 'bit' : 7 } ,
 'Twisted Pair (TP)' :
 { 'offset' : 9 ,
 'bit' : 6 } ,
 'Miniature Coax (MI)' :
 { 'offset' : 9 ,
 'bit' : 5 } ,
 'Video Coax (TV)' :
 { 'offset' : 9 ,
 'bit' : 4 } ,
 'Multimode, 62.5um (M6)' :
 { 'offset' : 9 ,
 'bit' : 3 } ,
 'Multimode, 50um (M5, M5E)' :
 { 'offset' : 9 ,
 'bit' : 2 } ,
 'Single Mode (SM)' :
 { 'offset' : 9 ,
 'bit' : 0 } } } ,
 'FibreChannelSpeed' :
 { 'offset' : 7 ,
 'size' : 2 ,
 'type' : 'bitmap' ,
 'decode' :
 { '1200 MBytes/sec' :
 { 'offset' : 10 ,
 'bit' : 7 } ,
 '800 MBytes/sec' :
 { 'offset' : 10 ,
 'bit' : 6 } ,
 '1600 MBytes/sec' :
 { 'offset' : 10 ,
 'bit' : 5 } ,
 '400 MBytes/sec' :
 { 'offset' : 10 ,
 'bit' : 4 } ,
 '200 MBytes/sec' :
 { 'offset' : 10 ,
 'bit' : 2 } ,
 '100 MBytes/sec' :
 { 'offset' : 10 ,
 'bit' : 0 } } } }
 type_of_transceiver = { '00' : 'Unknown' ,
 '01' : 'GBIC' ,
 '02' : 'Module soldered to motherboard' ,
 '03' : 'SFP or SFP Plus' ,
 '04' : '300 pin XBI' ,
 '05' : 'XENPAK' ,
 '06' : 'XFP' ,
 '07' : 'XFF' ,
 '08' : 'XFP-E' ,
 '09' : 'XPAK' ,
 '0a' : 'X2' ,
 '0b' : 'DWDM-SFP' ,
 '0d' : 'QSFP' }
 exttypeoftransceiver = { '00' : 'GBIC def not specified' ,
 '01' : 'GBIC is compliant with MOD_DEF 1' ,
 '02' : 'GBIC is compliant with MOD_DEF 2' ,
 '03' : 'GBIC is compliant with MOD_DEF 3' ,
 '04' : 'GBIC/SFP defined by twowire interface ID' ,
 '05' : 'GBIC is compliant with MOD_DEF 5' ,
 '06' : 'GBIC is compliant with MOD_DEF 6' ,
 '07' : 'GBIC is compliant with MOD_DEF 7' }
 connector = { '00' : 'Unknown' ,
 '01' : 'SC' ,
 '02' : 'Fibre Channel Style 1 copper connector' ,
 '03' : 'Fibre Channel Style 2 copper connector' ,
 '04' : 'BNC/TNC' ,
 '05' : 'Fibre Channel coaxial headers' ,
 '06' : 'FibreJack' ,
 '07' : 'LC' ,
 '08' : 'MT-RJ' ,
 '09' : 'MU' ,
 '0a' : 'SG' ,
 '0b' : 'Optical pigtail' ,
 '0c' : 'MPO Parallel Optic' ,
 '20' : 'HSSDCII' ,
 '21' : 'CopperPigtail' ,
 '22' : 'RJ45' ,
 '23' : 'No separable connector' }
 encoding_codes = { '00' : 'Unspecified' ,
 '01' : '8B/10B' ,
 '02' : '4B/5B' ,
 '03' : 'NRZ' ,
 '04' : 'Manchester' ,
 '05' : 'SONET Scrambled' ,
 '06' : '64B/66B' ,
 '07' : '256B/257B' }
 extended_compliance_codes = { '00' : 'Unspecified' ,
 '01' : '100G AOC or 25GAUI C2M AOC' ,
 '02' : '100GBASE-SR4 or 25GBASE-SR' ,
 '08' : '100GBASE ACC or 25GAUI C2M ACC' ,
 '0b' : '100GBASE-CR4 or 25GBASE-CR CA-L' ,
 '0c' : '25GBASE-CR CA-S' ,
 '0d' : '25GBASE-CR CA-N' ,
 '18' : '100G AOC or 25GAUI C2M AOC' ,
 '19' : '100G ACC or 25GAUI C2M ACC' }
 rate_identifier = { '00' : 'Unspecified' ,
 '01' : 'Defined for SFF-8079 (4/2/1G Rate_Select & AS0/AS1)' ,
 '02' : 'Defined for SFF-8431 (8/4/2G Rx Rate_Select only)' ,
 '03' : 'Unspecified' ,
 '04' : 'Defined for SFF-8431 (8/4/2G Tx Rate_Select only)' ,
 '05' : 'Unspecified' ,
 '06' : 'Defined for SFF-8431 (8/4/2G Independent Rx & Tx Rate_select)' ,
 '07' : 'Unspecified' ,
 '08' : 'Defined for FC-PI-5 (16/8/4G Rx Rate_select only) High=16G only, Low=8G/4G' ,
 '09' : 'Unspecified' ,
 '0a' : 'Defined for FC-PI-5 (16/8/4G Independent Rx, Tx Rate_select) High=16G only, Low=8G/4G' }
 def calc_length ( self , eeprom_data , offset , size ) :
  o00ooooO0oO = int ( eeprom_data [ offset ] , 16 )
  oOoOo00oOo = int ( eeprom_data [ offset + 1 ] , 16 )
  Oo = ( o00ooooO0oO << 8 ) | oOoOo00oOo
  return str ( "%d" % Oo )
 interface_id = { 'TypeOfTransceiver' :
 { 'offset' : 0 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : type_of_transceiver } ,
 'ExtIdentOfTypeOfTransceiver' :
 { 'offset' : 1 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'outlevel' : 2 ,
 'decode' : exttypeoftransceiver } ,
 'Connector' :
 { 'offset' : 2 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : connector } ,
 'EncodingCodes' :
 { 'offset' : 11 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : encoding_codes } ,
 'VendorName' :
 { 'offset' : 20 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'ExtendedComplianceCodes' :
 { 'offset' : 36 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : extended_compliance_codes } ,
 'VendorOUI' :
 { 'offset' : 37 ,
 'size' : 3 ,
 'type' : 'hex' } ,
 'VendorPN' :
 { 'offset' : 40 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'VendorSN' :
 { 'offset' : 68 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'VendorRev' :
 { 'offset' : 56 ,
 'size' : 4 ,
 'type' : 'str' } ,
 'CalibrationType' :
 { 'offset' : 92 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'short_name' : 'calType' ,
 'decode' : { 'Internally Calibrated' :
 { 'offset' : 92 ,
 'bit' : 5 } ,
 'Externally Calibrated' :
 { 'offset' : 92 ,
 'bit' : 4 } ,
 } } ,
 'ReceivedPowerMeasurementType' :
 { 'offset' : 92 ,
 'size' : 1 ,
 'type' : 'bitmap' ,
 'decode' : { 'Avg power' :
 { 'offset' : 92 ,
 'bit' : 3 } ,
 'OMA' :
 { 'offset' : 92 ,
 'bit' : 3 ,
 'value' : 0 } } } ,
 'RateIdentifier' :
 { 'offset' : 13 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : rate_identifier } ,
 'TransceiverCodes' :
 { 'offset' : 3 ,
 'type' : 'nested' ,
 'decode' : transceiver_codes } ,
 'NominalSignallingRate(UnitsOf100Mbd)' :
 { 'offset' : 12 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'LengthSMFkm-UnitsOfKm' :
 { 'offset' : 14 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'LengthSMF(UnitsOf100m)' :
 { 'offset' : 15 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'Length50um(UnitsOf10m)' :
 { 'offset' : 16 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'Length62.5um(UnitsOfm)' :
 { 'offset' : 17 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'LengthCable(UnitsOfm)' :
 { 'offset' : 18 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'LengthOM3(UnitsOf10m)' :
 { 'offset' : 19 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'VendorDateCode(YYYY-MM-DD Lot)' :
 { 'offset' : 84 ,
 'size' : 8 ,
 'type' : 'date' } ,
 'AliPN' :
 { 'offset' : 96 ,
 'size' : 16 ,
 'type' : 'str' } ,
 'LengthCable(UnitsOfmm)' :
 { 'offset' : 112 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_length } } ,
 'CableDiameter(UnitsOfmm)' :
 { 'offset' : 114 ,
 'size' : 1 ,
 'type' : 'int' } ,
 'LaneBitRate(UnitsOfGbps)' :
 { 'offset' : 115 ,
 'size' : 1 ,
 'type' : 'int' } }
 sfp_type = {
 'type' :
 { 'offset' : 0 ,
 'size' : 1 ,
 'type' : 'enum' ,
 'decode' : type_of_transceiver }
 }
 vendor_name = {
 'Vendor Name' :
 { 'offset' : 0 ,
 'size' : 16 ,
 'type' : 'str' }
 }
 vendor_pn = {
 'Vendor PN' :
 { 'offset' : 0 ,
 'size' : 16 ,
 'type' : 'str' }
 }
 vendor_rev = {
 'Vendor Rev' :
 { 'offset' : 0 ,
 'size' : 4 ,
 'type' : 'str' }
 }
 vendor_sn = {
 'Vendor SN' :
 { 'offset' : 0 ,
 'size' : 16 ,
 'type' : 'str' }
 }
 def _get_calibration_type ( self , eeprom_data ) :
  try :
   I11iii = int ( eeprom_data [ 92 ] , 16 )
   if self . test_bit ( I11iii , 5 ) != 0 :
    return 1
   elif self . test_bit ( I11iii , 4 ) != 0 :
    return 2
   else :
    return 0
  except :
   return 0
 def __init__ ( self , eeprom_raw_data = None ) :
  self . interface_data = None
  o0oO0o00oo = 0
  if eeprom_raw_data != None :
   self . interface_data = sffbase . parse ( self ,
 self . interface_id ,
 eeprom_raw_data , o0oO0o00oo )
   self . calibration_type = self . _get_calibration_type (
 eeprom_raw_data )
   self . handle_xcvr_type ( )
 def handle_xcvr_type ( self ) :
  if self . interface_data is not None and 'data' in self . interface_data and self . interface_data [ 'data' ] is not None :
   OO00o0OOO0 = self . interface_data [ 'data' ]
   if 'RateIdentifier' in OO00o0OOO0 :
    OO00o0OOO0 . pop ( 'RateIdentifier' )
   type = self . get_xcvr_type_detail ( OO00o0OOO0 )
   if type != "" :
    OO00o0OOO0 [ 'TypeOfTransceiver' ] [ 'value' ] = type
    OO00o0OOO0 . pop ( 'ExtendedComplianceCodes' )
    OO00o0OOO0 . pop ( 'ExtIdentOfTypeOfTransceiver' )
   sffbase . handle_xcvr_type ( self , type , OO00o0OOO0 )
 def get_xcvr_type_detail ( self , intf_data ) :
  type = ''
  try :
   III1i1i = intf_data [ 'TypeOfTransceiver' ] [ 'value' ]
   iiI1 = intf_data [ 'ExtendedComplianceCodes' ] [ 'value' ]
   if cmp ( III1i1i , 'SFP or SFP Plus' ) == 0 :
    if ( iiI1 . find ( '25GAUI' ) != - 1 ) or ( iiI1 . find ( '25GBASE' ) != - 1 ) :
     if iiI1 . find ( 'AOC' ) != - 1 :
      type = "25G_AOC_SFP28"
     elif iiI1 . find ( '-CR' ) != - 1 :
      type = "25G_DAC_SFP28"
     elif iiI1 . find ( '-SR' ) != - 1 :
      type = "25G_SR_SFP28"
  except Exception , ii1I1i1I :
   print ( 'Decode ID and ExtendedComplianceCodes Failed, %s' % str ( ii1I1i1I ) )
  return type
 def parse ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . interface_id , eeprom_raw_data , start_pos )
 def parse_sfp_type ( self , type_raw_data , start_pos ) :
  return sffbase . parse ( self , self . sfp_type , type_raw_data , start_pos )
 def parse_vendor_name ( self , name_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_name , name_raw_data , start_pos )
 def parse_vendor_rev ( self , rev_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_rev , rev_raw_data , start_pos )
 def parse_vendor_pn ( self , pn_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_pn , pn_raw_data , start_pos )
 def parse_vendor_sn ( self , sn_raw_data , start_pos ) :
  return sffbase . parse ( self , self . vendor_sn , sn_raw_data , start_pos )
 def dump_pretty ( self ) :
  if self . interface_data == None :
   return
  sffbase . dump_pretty ( self , self . interface_data )
 def get_calibration_type ( self ) :
  return self . calibration_type
 def get_data ( self ) :
  return self . interface_data
 def get_data_pretty ( self ) :
  if self . interface_data == None :
   return
  return sffbase . get_data_pretty ( self , self . interface_data )
class sff8472Dom ( sffbase ) :
 version = '1.0'
 dom_ext_calibration_constants = { 'RX_PWR_4' :
 { 'offset' : 56 ,
 'size' : 4 } ,
 'RX_PWR_3' :
 { 'offset' : 60 ,
 'size' : 4 } ,
 'RX_PWR_2' :
 { 'offset' : 64 ,
 'size' : 4 } ,
 'RX_PWR_1' :
 { 'offset' : 68 ,
 'size' : 4 } ,
 'RX_PWR_0' :
 { 'offset' : 72 ,
 'size' : 4 } ,
 'TX_I_Slope' :
 { 'offset' : 76 ,
 'size' : 2 } ,
 'TX_I_Offset' :
 { 'offset' : 78 ,
 'size' : 2 } ,
 'TX_PWR_Slope' :
 { 'offset' : 80 ,
 'size' : 2 } ,
 'TX_PWR_Offset' :
 { 'offset' : 82 ,
 'size' : 2 } ,
 'T_Slope' :
 { 'offset' : 84 ,
 'size' : 2 } ,
 'T_Offset' :
 { 'offset' : 86 ,
 'size' : 2 } ,
 'V_Slope' :
 { 'offset' : 88 ,
 'size' : 2 } ,
 'V_Offset' :
 { 'offset' : 90 ,
 'size' : 2 } }
 def get_calibration_type ( self ) :
  return self . _calibration_type
 def calc_temperature ( self , eeprom_data , offset , size ) :
  try :
   IIIIii = self . get_calibration_type ( )
   o00ooooO0oO = int ( eeprom_data [ offset ] , 16 )
   oOoOo00oOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Oo = ( o00ooooO0oO << 8 ) | ( oOoOo00oOo & 0xff )
   Oo = self . twos_comp ( Oo , 16 )
   if IIIIii == 1 :
    Oo = float ( Oo / 256.0 )
    iI1ii1Ii = '%.4f' % Oo + 'C'
   elif IIIIii == 2 :
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'T_Slope' ] [ 'offset' ]
    oO0o0OOOO = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    O0O0OoOO0 = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    iiiI1I11i1 = ( oO0o0OOOO << 8 ) | ( O0O0OoOO0 & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'T_Offset' ] [ 'offset' ]
    oO0o0OOOO = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    O0O0OoOO0 = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    O0oOO0 = ( oO0o0OOOO << 8 ) | ( O0O0OoOO0 & 0xff )
    O0oOO0 = self . twos_comp ( O0oOO0 , 16 )
    Oo = iiiI1I11i1 * Oo + O0oOO0
    Oo = float ( Oo / 256.0 )
    iI1ii1Ii = '%.4f' % Oo + 'C'
   else :
    iI1ii1Ii = 'Unknown'
  except Exception as o0 :
   iI1ii1Ii = str ( o0 )
  return iI1ii1Ii
 def calc_voltage ( self , eeprom_data , offset , size ) :
  try :
   IIIIii = self . get_calibration_type ( )
   o00ooooO0oO = int ( eeprom_data [ offset ] , 16 )
   oOoOo00oOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Oo = ( o00ooooO0oO << 8 ) | ( oOoOo00oOo & 0xff )
   if IIIIii == 1 :
    Oo = float ( Oo * 0.0001 )
    iI1ii1Ii = '%.4f' % Oo + 'Volts'
   elif IIIIii == 2 :
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'V_Slope' ] [ 'offset' ]
    O0OOO = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    II11iIiIIIiI = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    o0o = ( O0OOO << 8 ) | ( II11iIiIIIiI & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'V_Offset' ] [ 'offset' ]
    O0OOO = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    II11iIiIIIiI = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    OOOooOO0 = ( O0OOO << 8 ) | ( II11iIiIIIiI & 0xff )
    OOOooOO0 = self . twos_comp ( OOOooOO0 , 16 )
    Oo = o0o * Oo + OOOooOO0
    Oo = float ( Oo * 0.0001 )
    iI1ii1Ii = '%.4f' % Oo + 'Volts'
   else :
    iI1ii1Ii = 'Unknown'
  except Exception as o0 :
   iI1ii1Ii = str ( o0 )
  return iI1ii1Ii
 def calc_bias ( self , eeprom_data , offset , size ) :
  try :
   IIIIii = self . get_calibration_type ( )
   o00ooooO0oO = int ( eeprom_data [ offset ] , 16 )
   oOoOo00oOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Oo = ( o00ooooO0oO << 8 ) | ( oOoOo00oOo & 0xff )
   if IIIIii == 1 :
    Oo = float ( Oo * 0.002 )
    iI1ii1Ii = '%.4f' % Oo + 'mA'
   elif IIIIii == 2 :
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'I_Slope' ] [ 'offset' ]
    o00oooO0Oo = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    o0O0OOO0Ooo = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    iiIiI = ( o00oooO0Oo << 8 ) | ( o0O0OOO0Ooo & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'I_Offset' ] [ 'offset' ]
    o00oooO0Oo = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    o0O0OOO0Ooo = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    IiIiii1I1 = ( o00oooO0Oo << 8 ) | ( o0O0OOO0Ooo & 0xff )
    IiIiii1I1 = self . twos_comp ( IiIiii1I1 , 16 )
    Oo = iiIiI * Oo + IiIiii1I1
    Oo = float ( Oo * 0.002 )
    iI1ii1Ii = '%.4f' % Oo + 'mA'
   else :
    iI1ii1Ii = 'Unknown'
  except Exception as o0 :
   iI1ii1Ii = str ( o0 )
  return iI1ii1Ii
 def calc_tx_power ( self , eeprom_data , offset , size ) :
  try :
   IIIIii = self . get_calibration_type ( )
   o00ooooO0oO = int ( eeprom_data [ offset ] , 16 )
   oOoOo00oOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Oo = ( o00ooooO0oO << 8 ) | ( oOoOo00oOo & 0xff )
   if IIIIii == 1 :
    Oo = float ( Oo * 0.0001 )
    iI1ii1Ii = self . power_in_dbm_str ( Oo )
   elif IIIIii == 2 :
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'TX_PWR_Slope' ] [ 'offset' ]
    ooO0oOOooOo0 = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    i1I1ii11i1Iii = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    I1IiiiiI = ( ooO0oOOooOo0 << 8 ) | ( i1I1ii11i1Iii & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'TX_PWR_Offset' ] [ 'offset' ]
    ooO0oOOooOo0 = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    i1I1ii11i1Iii = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    iIiIIi1 = ( ooO0oOOooOo0 << 8 ) | ( i1I1ii11i1Iii & 0xff )
    iIiIIi1 = self . twos_comp ( iIiIIi1 , 16 )
    Oo = I1IiiiiI * Oo + iIiIIi1
    Oo = float ( Oo * 0.0001 )
    iI1ii1Ii = self . power_in_dbm_str ( Oo )
   else :
    iI1ii1Ii = 'Unknown'
  except Exception as o0 :
   iI1ii1Ii = str ( o0 )
  return iI1ii1Ii
 def calc_rx_power ( self , eeprom_data , offset , size ) :
  try :
   IIIIii = self . get_calibration_type ( )
   o00ooooO0oO = int ( eeprom_data [ offset ] , 16 )
   oOoOo00oOo = int ( eeprom_data [ offset + 1 ] , 16 )
   Oo = ( o00ooooO0oO << 8 ) | ( oOoOo00oOo & 0xff )
   if IIIIii == 1 :
    Oo = float ( Oo * 0.0001 )
    iI1ii1Ii = self . power_in_dbm_str ( Oo )
   elif IIIIii == 2 :
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'RX_PWR_4' ] [ 'offset' ]
    i1i = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    oOOoo00O00o = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    O0O00Oo = int ( eeprom_data [ I1i1IiI1 + 2 ] , 16 )
    oooooo0O000o = int ( eeprom_data [ I1i1IiI1 + 3 ] , 16 )
    OoO = ( i1i << 24 ) | ( oOOoo00O00o << 16 ) | ( O0O00Oo << 8 ) | ( oooooo0O000o & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'RX_PWR_3' ] [ 'offset' ]
    i1i = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    oOOoo00O00o = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    O0O00Oo = int ( eeprom_data [ I1i1IiI1 + 2 ] , 16 )
    oooooo0O000o = int ( eeprom_data [ I1i1IiI1 + 3 ] , 16 )
    OO0ooOOO0OOO = ( i1i << 24 ) | ( oOOoo00O00o << 16 ) | ( O0O00Oo << 8 ) | ( oooooo0O000o & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'RX_PWR_2' ] [ 'offset' ]
    i1i = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    oOOoo00O00o = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    O0O00Oo = int ( eeprom_data [ I1i1IiI1 + 2 ] , 16 )
    oooooo0O000o = int ( eeprom_data [ I1i1IiI1 + 3 ] , 16 )
    oo = ( i1i << 24 ) | ( oOOoo00O00o << 16 ) | ( O0O00Oo << 8 ) | ( oooooo0O000o & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'RX_PWR_1' ] [ 'offset' ]
    i1i = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    oOOoo00O00o = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    O0O00Oo = int ( eeprom_data [ I1i1IiI1 + 2 ] , 16 )
    oooooo0O000o = int ( eeprom_data [ I1i1IiI1 + 3 ] , 16 )
    OOO = ( i1i << 24 ) | ( oOOoo00O00o << 16 ) | ( O0O00Oo << 8 ) | ( oooooo0O000o & 0xff )
    I1i1IiI1 = self . dom_ext_calibration_constants [ 'RX_PWR_0' ] [ 'offset' ]
    i1i = int ( eeprom_data [ I1i1IiI1 ] , 16 )
    oOOoo00O00o = int ( eeprom_data [ I1i1IiI1 + 1 ] , 16 )
    O0O00Oo = int ( eeprom_data [ I1i1IiI1 + 2 ] , 16 )
    oooooo0O000o = int ( eeprom_data [ I1i1IiI1 + 3 ] , 16 )
    oooOo0OOOoo0 = ( i1i << 24 ) | ( oOOoo00O00o << 16 ) | ( O0O00Oo << 8 ) | ( oooooo0O000o & 0xff )
    OOOoOo = ( OoO * Oo ) + ( OO0ooOOO0OOO * Oo ) + ( oo * Oo ) + ( OOO * Oo ) + oooOo0OOOoo0
    Oo = float ( Oo * 0.0001 )
    iI1ii1Ii = self . power_in_dbm_str ( Oo )
   else :
    iI1ii1Ii = 'Unknown'
  except Exception as o0 :
   iI1ii1Ii = str ( o0 )
  return iI1ii1Ii
 def decode_tx_equalization ( self , eeprom_data , offset , size ) :
  oO00O000oO0 = ( int ( eeprom_data [ offset ] , 16 ) >> 4 ) & 0xf
  if oO00O000oO0 not in range ( 11 ) :
   Oo = "Reserved"
  else :
   Oo = str ( oO00O000oO0 ) + " dB"
  return Oo
 def decode_rx_emphasis ( self , eeprom_data , offset , size ) :
  oO00O000oO0 = ( int ( eeprom_data [ offset ] , 16 ) >> 4 ) & 0xf
  if oO00O000oO0 not in range ( 11 ) :
   Oo = "Reserved"
  else :
   Oo = str ( oO00O000oO0 ) + " dB"
  return Oo
 dom_aw_thresholds = { 'TempHighAlarm' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } } ,
 'TempLowAlarm' :
 { 'offset' : 2 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } } ,
 'TempHighWarning' :
 { 'offset' : 4 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } } ,
 'TempLowWarning' :
 { 'offset' : 6 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } } ,
 'VoltageHighAlarm' :
 { 'offset' : 8 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } } ,
 'VoltageLowAlarm' :
 { 'offset' : 10 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } } ,
 'VoltageHighWarning' :
 { 'offset' : 12 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } } ,
 'VoltageLowWarning' :
 { 'offset' : 14 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } } ,
 'BiasHighAlarm' :
 { 'offset' : 16 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'BiasLowAlarm' :
 { 'offset' : 18 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'BiasHighWarning' :
 { 'offset' : 20 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'BiasLowWarning' :
 { 'offset' : 22 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TXPowerHighAlarm' :
 { 'offset' : 24 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'TXPowerLowAlarm' :
 { 'offset' : 26 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'TXPowerHighWarning' :
 { 'offset' : 28 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'TXPowerLowWarning' :
 { 'offset' : 30 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'RXPowerHighAlarm' :
 { 'offset' : 32 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RXPowerLowAlarm' :
 { 'offset' : 34 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RXPowerHighWarning' :
 { 'offset' : 36 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } ,
 'RXPowerLowWarning' :
 { 'offset' : 38 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } }
 dom_monitor = { 'Temperature' :
 { 'offset' : 96 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } } ,
 'Vcc' :
 { 'offset' : 98 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } } ,
 'TXBias' :
 { 'offset' : 100 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TXPower' :
 { 'offset' : 102 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'RXPower' :
 { 'offset' : 104 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } } }
 dom_optional_status = {

 'TXFault' :
 { 'offset' : 110 ,
 'bit' : 2 ,
 'type' : 'bitvalue' } ,
 'RXLOS' :
 { 'offset' : 110 ,
 'bit' : 1 ,
 'type' : 'bitvalue' } ,

 'TXLOL' :
 { 'offset' : 119 ,
 'bit' : 1 ,
 'type' : 'bitvalue' } ,
 'RXLOL' :
 { 'offset' : 119 ,
 'bit' : 0 ,
 'type' : 'bitvalue' } }
 dom_alarm_flags = { 'TempHighAlarm' :
 { 'offset' : 112 ,
 'bit' : 7 ,
 'type' : 'bitvalue' } ,
 'TempLowAlarm' :
 { 'offset' : 112 ,
 'bit' : 6 ,
 'type' : 'bitvalue' } ,
 'VccHighAlarm' :
 { 'offset' : 112 ,
 'bit' : 5 ,
 'type' : 'bitvalue' } ,
 'VccLowAlarm' :
 { 'offset' : 112 ,
 'bit' : 4 ,
 'type' : 'bitvalue' } ,
 'TXBiasHighAlarm' :
 { 'offset' : 112 ,
 'bit' : 3 ,
 'type' : 'bitvalue' } ,
 'TXBiasLowAlarm' :
 { 'offset' : 112 ,
 'bit' : 2 ,
 'type' : 'bitvalue' } ,
 'TXPowerHighAlarm' :
 { 'offset' : 112 ,
 'bit' : 1 ,
 'type' : 'bitvalue' } ,
 'TXPowerLowAlarm' :
 { 'offset' : 112 ,
 'bit' : 0 ,
 'type' : 'bitvalue' } ,
 'RXPowerHighAlarm' :
 { 'offset' : 113 ,
 'bit' : 7 ,
 'type' : 'bitvalue' } ,
 'RXPowerLowAlarm' :
 { 'offset' : 113 ,
 'bit' : 6 ,
 'type' : 'bitvalue' } }
 dom_optional_control = {
 'TXEQ' : {
 'offset' : 114 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_tx_equalization
 }
 } ,
 'RXEmphasis' : {
 'offset' : 115 ,
 'size' : 1 ,
 'type' : 'func' ,
 'decode' : {
 'func' : decode_rx_emphasis
 }
 }
 }
 dom_warning_flags = { 'TempHighWarning' :
 { 'offset' : 116 ,
 'bit' : 7 ,
 'type' : 'bitvalue' } ,
 'TempLowWarning' :
 { 'offset' : 116 ,
 'bit' : 6 ,
 'type' : 'bitvalue' } ,
 'VccHighWarning' :
 { 'offset' : 116 ,
 'bit' : 5 ,
 'type' : 'bitvalue' } ,
 'VccLowWarning' :
 { 'offset' : 116 ,
 'bit' : 4 ,
 'type' : 'bitvalue' } ,
 'TXBiasHighWarning' :
 { 'offset' : 116 ,
 'bit' : 3 ,
 'type' : 'bitvalue' } ,
 'TXBiasLowWarning' :
 { 'offset' : 116 ,
 'bit' : 2 ,
 'type' : 'bitvalue' } ,
 'TXPowerHighWarning' :
 { 'offset' : 116 ,
 'bit' : 1 ,
 'type' : 'bitvalue' } ,
 'TXPowerLowWarning' :
 { 'offset' : 116 ,
 'bit' : 0 ,
 'type' : 'bitvalue' } ,
 'RXPowerHighWarning' :
 { 'offset' : 117 ,
 'bit' : 7 ,
 'type' : 'bitvalue' } ,
 'RXPowerLowWarning' :
 { 'offset' : 117 ,
 'bit' : 6 ,
 'type' : 'bitvalue' } }
 dom_map = { 'AwThresholds' :
 { 'offset' : 0 ,
 'size' : 40 ,
 'type' : 'nested' ,
 'decode' : dom_aw_thresholds } ,
 'MonitorData' :
 { 'offset' : 96 ,
 'size' : 10 ,
 'type' : 'nested' ,
 'decode' : dom_monitor } ,
 'OptionalStatus' :
 { 'offset' : 110 ,
 'size' : 1 ,
 'type' : 'nested' ,
 'decode' : dom_optional_status } ,
 'AlarmFlagStatus' :
 { 'offset' : 112 ,
 'size' : 2 ,
 'type' : 'nested' ,
 'decode' : dom_alarm_flags } ,
 'WarningFlagStatus' :
 { 'offset' : 112 ,
 'size' : 2 ,
 'type' : 'nested' ,
 'decode' : dom_warning_flags } ,
 'OptionalControls' :
 { 'offset' : 114 ,
 'size' : 2 ,
 'type' : 'nested' ,
 'decode' : dom_optional_control } }
 dom_module_temperature = {
 'Temperature' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_temperature } }
 }
 dom_module_voltage = {
 'Vcc' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_voltage } }
 }
 dom_channel_monitor_params = {
 'TXBias' :
 { 'offset' : 0 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_bias } } ,
 'TXPower' :
 { 'offset' : 2 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_tx_power } } ,
 'RXPower' :
 { 'offset' : 4 ,
 'size' : 2 ,
 'type' : 'func' ,
 'decode' : { 'func' : calc_rx_power } }
 }
 def __init__ ( self , eeprom_raw_data = None , calibration_type = 0 ) :
  self . _calibration_type = calibration_type
  o0oO0o00oo = 0
  if eeprom_raw_data != None :
   self . dom_data = sffbase . parse ( self , self . dom_map ,
 eeprom_raw_data , o0oO0o00oo )
 def parse ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_map , eeprom_raw_data , start_pos )
 def parse_temperature ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_module_temperature , eeprom_raw_data ,
 start_pos )
 def parse_voltage ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_module_voltage , eeprom_raw_data ,
 start_pos )
 def parse_channel_monitor_params ( self , eeprom_raw_data , start_pos ) :
  return sffbase . parse ( self , self . dom_channel_monitor_params , eeprom_raw_data ,
 start_pos )
 def dump_pretty ( self ) :
  if self . dom_data == None :
   return
  sffbase . dump_pretty ( self , self . dom_data )
 def get_data ( self ) :
  return self . dom_data
 def get_data_pretty ( self ) :
  return sffbase . get_data_pretty ( self , self . dom_data )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
